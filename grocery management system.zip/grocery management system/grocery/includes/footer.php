<footer class="ec-footer">

  <div class="footer-container">
    <div class="footer-top section-space-footer-p">
      <div class="container">
        <div class="row">
          <div class="col-sm-12 col-lg-3 ec-footer-cat">
            <div class="ec-footer-widget">
              <h4 class="ec-footer-heading">Popular Categories</h4>
              <div class="ec-footer-links">
                <ul class="align-items-center">
                  <li class="ec-footer-link"><a href="#">Fresh Vegetables</a></li>
                  <li class="ec-footer-link"><a href="#">Fruit juice</a></li>
                  <li class="ec-footer-link"><a href="#">Fresh Fruits</a></li>
                  <li class="ec-footer-link"><a href="#">Organic</a></li>
                  <li class="ec-footer-link"><a href="#">Greens</a></li>
                </ul>
              </div>
            </div>
          </div>
          <div class="col-sm-12 col-lg-3 ec-footer-info">
            <div class="ec-footer-widget">
              <h4 class="ec-footer-heading">Products</h4>
              <div class="ec-footer-links">
                <ul class="align-items-center">
                  <?php
                  $ret=mysqli_query($con,"select * from tblproducts order by rand() limit 5");
                  while ($row=mysqli_fetch_array($ret)) 
                  {
                    ?>
                    <li  class="ec-footer-link"><a href="product.php?pid=<?php echo htmlentities($row['id']);?>"><?php echo substr($row['ProductName'],0,30);?></a></li>
                    <?php
                  }?>
                  
                </ul>
              </div>
            </div>
          </div>
          <div class="col-sm-12 col-lg-3 ec-footer-account">
            <div class="ec-footer-widget">
              <h4 class="ec-footer-heading">Our Company</h4>
              <div class="ec-footer-links">
                <ul class="align-items-center">
                  <li class="ec-footer-link"><a href="track-order.html">Delivery</a></li>
                  <li class="ec-footer-link"><a href="privacy-policy.html">Legal Notice</a></li>
                  <li class="ec-footer-link"><a href="terms-condition.html">Terms and conditions</a></li>
                  <li class="ec-footer-link"><a href="about-us.html">About us</a></li>
                  <li class="ec-footer-link"><a href="checkout.html">Secure payment</a></li>
                </ul>
              </div>
            </div>
          </div>
          <div class="col-sm-12 col-lg-3 ec-footer-service">
            <div class="ec-footer-widget">
              <h4 class="ec-footer-heading">Services</h4>
              <div class="ec-footer-links">
                <ul class="align-items-center">
                  <li class="ec-footer-link"><a href="#">Prices drop</a></li>
                  <li class="ec-footer-link"><a href="#">New products</a></li>
                  <li class="ec-footer-link"><a href="#">Best sales</a></li>
                  <li class="ec-footer-link"><a href="contactus.php">Contact us</a></li>
                  <li class="ec-footer-link"><a href="#">Sitemap</a></li>
                </ul>
              </div>
            </div>
          </div>
          <div class="col-sm-12 col-lg-3 ec-footer-cont-social">
            <div class="ec-footer-contact">
              <div class="ec-footer-widget">
                <h4 class="ec-footer-heading">Contact</h4>
                <div class="ec-footer-links">
                  <ul class="align-items-center">
                    <li class="ec-footer-link ec-foo-location"><span><img
                      src="assets/images/icons/foo-location.svg"
                      class="svg_img foo_svg" alt="" /></span>
                      <p>3813 Ross Clark Cir Suite 500 & 600, Dothan, AL 36303</p>
                    </li>
                    <li class="ec-footer-link ec-foo-call"><span><img
                      src="assets/images/icons/foo-wp.svg" class="svg_img foo_svg"
                      alt="" /></span><a href="tel:+919999999999">+1 334-686-4470</a>
                    </li>
                    <li class="ec-footer-link ec-foo-mail"><span><img
                      src="assets/images/icons/foo-wp.svg" class="svg_img foo_svg"
                      alt="" /></span><a href="#">info@support.com</a>
                    </li>
                  </ul>
                </div>
              </div>
            </div>
            <div class="ec-footer-social">
              <div class="ec-footer-widget">
                <h4 class="ec-footer-heading marg-b-0 s-head">Follow Us</h4>
                <div class="ec-footer-links">
                  <ul class="align-items-center">
                    <li class="ec-footer-link"><a href="#"><i class="ecicon eci-instagram"
                      aria-hidden="true"></i></a>
                    </li>
                    <li class="ec-footer-link"><a href="#"><i class="ecicon eci-twitter-square"
                      aria-hidden="true"></i></a>
                    </li>
                    <li class="ec-footer-link"><a href="#"><i class="ecicon eci-facebook-square"
                      aria-hidden="true"></i></a>
                    </li>
                    <li class="ec-footer-link"><a href="#"><i class="ecicon eci-linkedin-square"
                      aria-hidden="true"></i></a>
                    </li>
                  </ul>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    <div class="footer-bottom">
      <div class="container">
        <div class="row">
          <!-- Footer payment -->
          <div class="footer-bottom-right">
            <div class="footer-bottom-payment d-flex justify-content-center">
              <div class="payment-link">
                <img src="assets/images/icons/payment.png" alt="">
              </div>

            </div>
          </div>
          <!-- Footer payment -->
          <!-- Footer Copyright Start -->
          <div class="footer-copy">
            <div class="footer-bottom-copy ">
              <div class="ec-copy">Copyright © <a class="site-name" href="index.html">Pavan Bharadwaj</a> all
              rights reserved.</div>
            </div>
          </div>
          <!-- Footer Copyright End -->

        </div>
      </div>
    </div>
  </div>
</footer>
