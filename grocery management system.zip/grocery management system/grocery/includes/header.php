<header class="ec-header">
  <!--Ec Header Top Start -->
  <div class="header-top">
    <div class="container">
      <div class="row align-items-center">
        <!-- Header Top social Start -->
        <div class="col text-left header-top-left d-none d-lg-block">
          <div class="header-top-social">
            <ul class="mb-0">
              <li class="list-inline-item"><a href="#"><i class="ecicon eci-facebook"></i></a></li>
              <li class="list-inline-item"><a href="#"><i class="ecicon eci-twitter"></i></a></li>
              <li class="list-inline-item"><a href="#"><i class="ecicon eci-youtube-play"></i></a>
              </li>
              <li class="list-inline-item"><a href="#"><i class="ecicon eci-vimeo"></i></a></li>
              <li class="list-inline-item"><a href="#"><i class="ecicon eci-instagram"></i></a></li>
            </ul>
          </div>
        </div>
        <!-- Header Top social End -->
        <!-- Header Top Message Start -->
        <div class="col text-center header-top-center">
          <div class="header-top-message">
            World's Fastest Online Shopping Destination
          </div>
        </div>
        <!-- Header Top Message End -->
        <!-- Header Top Language Currency -->
        <div class="col header-top-right d-none d-lg-block">
          <div class="header-top-right-inner d-flex justify-content-end">
            <!-- Language Start -->
            <div class="header-top-lan-curr header-top-lan dropdown">
              <button class="dropdown-toggle" data-bs-toggle="dropdown">English <i
                class="ecicon eci-angle-down" aria-hidden="true"></i>
              </button>
              <ul class="dropdown-menu">
                <li class="active"><a class="dropdown-item" href="#">English</a></li>
                <li><a class="dropdown-item" href="#">Italiano</a></li>
              </ul>
            </div>
            <!-- Language End -->
            <!-- Currency Start -->
            <div class="header-top-lan-curr header-top-curr dropdown">
              <button class="dropdown-toggle" data-bs-toggle="dropdown">Dollar <i
                class="ecicon eci-angle-down" aria-hidden="true"></i>
              </button>
              <ul class="dropdown-menu">
                <li class="active"><a class="dropdown-item" href="#">USD $</a></li>
                <li><a class="dropdown-item" href="#">INR</a></li>
              </ul>
            </div>
            <!-- Currency End -->

          </div>
        </div>
        <!-- Header Top Language Currency -->
        <!-- Header Top responsive Action -->
        <div class="col header-top-res d-lg-none">
          <div class="ec-header-bottons">
            <!-- Header User Start -->
            <a href="user-profile.php" class="ec-header-btn ec-header-user">
              <div class="header-icon"><img src="assets/images/icons/user.svg"
                class="svg_img header_svg" alt="" />
              </div>
            </a>
            <!-- Header User End -->
            <!-- Header Cart Start -->
            <a href="wishlist.php" class="ec-header-btn ec-header-wishlist">
              <div class="header-icon"><img src="assets/images/icons/wishlist.svg"
                class="svg_img header_svg" alt="" />
              </div>
              <?php
              if(strlen($_SESSION['login'])==0)
              {   
                ?>
                <span class="ec-header-count ec-wishlist-count">0</span>
                <?php
              }
              else{
                $ret=mysqli_query($con,"select count(userId) as total  from wishlist where userId='".$_SESSION['id']."'");
                $num=mysqli_fetch_array($ret);
                $count=$num['total'];
                ?>
                <span class="ec-header-count ec-wishlist-count"><?php echo $count?></span>
                <?php
              }?>
            </a>
            <!-- Header Cart End -->
            <!-- Header Cart Start -->
            <a href="#ec-side-cart" class="ec-header-btn ec-side-toggle">
              <div class="header-icon"><img src="assets/images/icons/cart.svg"
                class="svg_img header_svg" alt="" />
              </div>
              <?php
              if(!empty($_SESSION['cart']))
              {
                $sql = "SELECT * FROM tblproducts WHERE id IN(";
                foreach($_SESSION['cart'] as $id => $value){
                  $sql .=$id. ",";
                }
                $sql=substr($sql,0,-1) . ") ORDER BY id ASC";
                $query = mysqli_query($con,$sql);
                $totalprice=0;
                $totalqunty=0;
                if(!empty($query)){
                  while($row = mysqli_fetch_array($query))
                  {
                    $quantity=$_SESSION['cart'][$row['id']]['quantity'];
                    $subtotal= $_SESSION['cart'][$row['id']]['quantity']*$row['ProductPrice'];
                    $totalprice += $subtotal;
                    $_SESSION['qnty']=$totalqunty+=$quantity;
                  }
                }
                ?>
                <span class="ec-header-count ec-cart-count"><?php echo $_SESSION['qnty'];?></span>
                <span class="ec-btn-stitle"><b class="ec-cart-count"><?php echo $_SESSION['qnty'];?></b>-items</span>
                <?php
              }else{?>
                <span class="ec-header-count ec-cart-count">0</span>
                <?php
              }
              ?>

            </a>
            <!-- Header Cart End -->
            <!-- Header menu Start -->
            <a href="#ec-mobile-menu" class="ec-header-btn ec-side-toggle d-lg-none">
              <i class="ecicon eci-bars"></i>
            </a>
            <!-- Header menu End -->
          </div>
        </div>
        <!-- Header Top responsive Action -->
      </div>
    </div>
  </div>
  <!-- Ec Header Top  End -->
  <!-- Ec Header Bottom  Start -->
  <div class="ec-header-bottom d-none d-lg-block">
    <div class="container position-relative">
      <div class="row">
        <div class="ec-flex">
          <!-- Ec Header Logo Start -->
          <div class="align-self-center ec-header-logo">
            <div class="header-logo">
              <a href="index.php"><img src="assets/images/logo/swagat-logo.png" alt="Site Logo" /><img
                class="dark-logo" src="assets/images/logo/dark-logo-6.png" alt="Site Logo"
                style="display: none;" />
              </a>
            </div>
          </div>
          <!-- Ec Header Logo End -->

          <!-- Ec Header Search Start -->
          <div class="align-self-center ec-header-search">
            <div class="header-search">
              <form class="ec-search-group-form" action="#">
                <div class="ec-search-select-inner">
                  <select name="ec-search-cat" id="ec-search-cat">
                    <option selected disabled>Category</option>
                    <option value="cloths">Vegetables</option>
                    <option value="bag">Fast Food</option>
                    <option value="shoes">Fresh Seafood</option>
                  </select>
                </div>
                <input class="form-control" placeholder="Search Your Products..." type="text">
                <button class="search_submit" type="submit"><img src="assets/images/icons/search.svg"
                  class="svg_img search_svg" alt="" />
                </button>
              </form>
            </div>
          </div>
          <!-- Ec Header Search End -->

          <!-- Ec Header Button Start -->
          <div class="align-self-center">
            <div class="ec-header-bottons">
              <!-- Header User Start -->
              <a href="user-profile.php" class="ec-header-btn ec-header-user">
                <div class="header-icon"><img src="assets/images/icons/user.svg"
                  class="svg_img header_svg" alt="" />
                </div>
                <div class="ec-btn-desc">
                  <span class="ec-btn-title">Account</span>
                  <?php if(strlen($_SESSION['login'])==0)
                  {   ?>
                    <a class="dropdown-item" href="login.php"><span class="ec-btn-stitle">Login</span></a>
                  <?php }
                  else{ ?>
                    <a class="dropdown-item" href="logout.php"><span class="ec-btn-stitle">Logout</span></a>
                    <?php

                  } ?>
                  
                </div>
              </a>
              <!-- Header User End -->
              <!-- Header wishlist Start -->
              <a href="wishlist.php" class="ec-header-btn ec-header-wishlist">
                <div class="header-icon"><img src="assets/images/icons/wishlist.svg"
                  class="svg_img header_svg" alt="" />
                </div>
                <div class="ec-btn-desc">
                  <span class="ec-btn-title">Wishlist</span>
                  <?php
                  if(strlen($_SESSION['login'])==0)
                  {   
                    ?>
                    <span class="ec-btn-stitle"><b class="ec-wishlist-count">0</b>-items</span>
                    <?php
                  }
                  else{
                    $ret=mysqli_query($con,"select count(userId) as total  from wishlist where userId='".$_SESSION['id']."'");
                    $num=mysqli_fetch_array($ret);
                    $count=$num['total'];
                    ?>
                    <span class="ec-btn-stitle"><b class="ec-wishlist-count"><?php echo $count?></b>-items</span>
                    <?php
                  }?>
                  
                </div>
              </a>
              <!-- Header wishlist End -->
              <!-- Header Cart Start -->
              <a href="#ec-side-cart" class="ec-header-btn ec-side-toggle">
                <div class="header-icon"><img src="assets/images/icons/cart.svg"
                  class="svg_img header_svg" alt="" />
                </div>
                <div class="ec-btn-desc">
                  <span class="ec-btn-title">Cart</span>
                  <?php
                  if(!empty($_SESSION['cart']))
                  {
                    $sql = "SELECT * FROM tblproducts WHERE id IN(";
                    foreach($_SESSION['cart'] as $id => $value){
                      $sql .=$id. ",";
                    }
                    $sql=substr($sql,0,-1) . ") ORDER BY id ASC";
                    $query = mysqli_query($con,$sql);
                    $totalprice=0;
                    $totalqunty=0;
                    if(!empty($query)){
                      while($row = mysqli_fetch_array($query))
                      {
                        $quantity=$_SESSION['cart'][$row['id']]['quantity'];
                        $subtotal= $_SESSION['cart'][$row['id']]['quantity']*$row['ProductPrice'];
                        $totalprice += $subtotal;
                        $_SESSION['qnty']=$totalqunty+=$quantity;
                      }
                    }
                    ?>
                    <span class="ec-btn-stitle"><b class="ec-cart-count"><?php echo $_SESSION['qnty'];?></b>-items</span>
                    <?php
                  }else{?>
                    <span class="ec-btn-stitle"><b class="ec-cart-count">0</b>-items</span>
                    <?php
                  }
                  ?>

                </div>
              </a>
              <!-- Header Cart End -->
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
  <!-- Ekka Menu Start -->
  <div id="ec-mobile-menu" class="ec-side-cart ec-mobile-menu">
    <div class="ec-menu-title">
      <span class="menu_title">My Menu</span>
      <button class="ec-close">×</button>
    </div>
    <div class="ec-menu-inner">
      <div class="ec-menu-content">
        <ul>
          <li><a href="index.php">Home</a></li>

          <li><a href="javascript:void(0)">Categories</a>
            <ul class="sub-menu">
              <li>
                <a href="javascript:void(0)">Fresh Vegetables</a>
                <ul class="sub-menu">
                  <?php
                  $ret2=mysqli_query($con,"select * from tblproducts where CategoryName='78' order by rand() limit 5");
                  while ($row2=mysqli_fetch_array($ret2)) 
                  {
                    ?>
                    <li><a href="product.php?pid=<?php echo htmlentities($row2['id']);?>"><?php echo substr($row2['ProductName'],0,25);?></a>
                    </li>
                    <?php
                  }?>
                </ul>
              </li>
              <li>
                <a href="javascript:void(0)">Fresh Fruits</a>
                <ul class="sub-menu">
                  <?php
                  $ret3=mysqli_query($con,"select * from tblproducts where CategoryName='79' order by rand() limit 5");
                  while ($row3=mysqli_fetch_array($ret3)) 
                  {
                    ?>
                    <li><a href="product.php?pid=<?php echo htmlentities($row3['id']);?>"><?php echo substr($row3['ProductName'],0,25);?></a>
                    </li>
                    <?php
                  }?>
                </ul>
              </li>
              <li>
                <a href="javascript:void(0)">Vegetables</a>
                <ul class="sub-menu">
                  <?php
                  $ret4=mysqli_query($con,"select * from tblproducts where CategoryName='78' order by rand() limit 5");
                  while ($row4=mysqli_fetch_array($ret4)) 
                  {
                    ?>
                    <li><a href="product.php?pid=<?php echo htmlentities($row4['id']);?>"><?php echo substr($row4['ProductName'],0,25);?></a>
                    </li>
                    <?php
                  }?>
                </ul>
              </li>
              <li>
                <a href="javascript:void(0)">Fruits</a>
                <ul class="sub-menu">
                  <?php
                  $ret5=mysqli_query($con,"select * from tblproducts where CategoryName='79' order by rand() limit 5");
                  while ($row5=mysqli_fetch_array($ret5)) 
                  {
                    ?>
                    <li><a href="product.php?pid=<?php echo htmlentities($row5['id']);?>"><?php echo substr($row5['ProductName'],0,25);?></a>
                    </li>
                    <?php
                  }?>
                </ul>
              </li>
            </ul>
          </li>
          <li><a href="javascript:void(0)">Products</a>
            <ul class="sub-menu">
              <?php
              $ret=mysqli_query($con,"select * from tblproducts order by rand() limit 6");
              while ($row=mysqli_fetch_array($ret)) 
              {
                ?>
                <li><a href="product.php?pid=<?php echo htmlentities($row['id']);?>"><?php echo substr($row['ProductName'],0,30);?></a></li>
                <?php
              }?>
            </ul>
          </li>
        </ul>
      </div>
      <div class="header-res-lan-curr">
        <div class="header-top-lan-curr">
          <!-- Language Start -->
          <div class="header-top-lan dropdown">
            <button class="dropdown-toggle text-upper" data-bs-toggle="dropdown">Language <i
              class="ecicon eci-caret-down" aria-hidden="true"></i>
            </button>
            <ul class="dropdown-menu">
              <li class="active"><a class="dropdown-item" href="#">English</a></li>
              <li><a class="dropdown-item" href="#">Italiano</a></li>
            </ul>
          </div>
          <!-- Language End -->
          <!-- Currency Start -->
          <div class="header-top-curr dropdown">
            <button class="dropdown-toggle text-upper" data-bs-toggle="dropdown">Currency <i
              class="ecicon eci-caret-down" aria-hidden="true"></i>
            </button>
            <ul class="dropdown-menu">
              <li class="active"><a class="dropdown-item" href="#">USD $</a></li>
              <li><a class="dropdown-item" href="#">EUR €</a></li>
            </ul>
          </div>
          <!-- Currency End -->
        </div>
        <!-- Social Start -->
        <div class="header-res-social">
          <div class="header-top-social">
            <ul class="mb-0">
              <li class="list-inline-item"><a href="#"><i class="ecicon eci-facebook"></i></a></li>
              <li class="list-inline-item"><a href="#"><i class="ecicon eci-twitter"></i></a></li>
              <li class="list-inline-item"><a href="#"><i class="ecicon eci-instagram"></i></a></li>
              <li class="list-inline-item"><a href="#"><i class="ecicon eci-linkedin"></i></a></li>
            </ul>
          </div>
        </div>
        <!-- Social End -->
      </div>
    </div>
  </div>
  <!-- Ekka Menu End -->
  <!-- Ec Header Button End -->
  <div class="ec-header-cat d-none d-lg-block">
    <div class="container position-relative">
      <div class="row ">
        <div class="col ec-category-block">
          <div class="ec-category-menu">
            <div class="ec-category-toggle">
              <i class="ecicon eci-bars"></i>
              <span class="ec-category-title d-1199">Shop By Category</span>
              <i class="ecicon eci-angle-down d-1199" aria-hidden="true"></i>
            </div>
            <div class="ec-category-content">
              <div class="ec-category-dropdown">
                <ul class="ec-category-wrapper">
                  <li><a title="Juice & Drinks" class="ec-cat-menu-link" href="product.php?pid=94">
                    <img src="assets/images/icons/drink-6.svg"
                    class="svg_img search_svg" alt="" />juice & drinks</a>
                  </li>
                  <li><a title="Fresh Fruits" class="ec-cat-menu-link" href="product.php?pid=86">
                    <img src="assets/images/icons/fruit-6.svg"
                    class="svg_img search_svg" alt="" />Fresh Fruits</a>
                  </li>
                  <li><a title="Snack & Spices" class="ec-cat-menu-link" href="product.php?pid=90">
                    <img src="assets/images/icons/pack-6.svg"
                    class="svg_img search_svg" alt="" />Snack & Spices</a>
                  </li>
                  <li><a title="Vegetables" class="ec-cat-menu-link" href="product.php?pid=93">
                    <img src="assets/images/icons/vege-6.svg"
                    class="svg_img search_svg" alt="" />Vegetables</a>
                  </li>
                  <li class="show"><a title="" class="ec-cat-menu-link" href="product.php?pid=92">Show more <img src="assets/images/common/arrow-dropdown.png" alt=""></a>
                  </li>
                </ul>
              </div>
            </div>
          </div>
        </div>

        <!-- EC Main Menu Start -->
        <div id="ec-main-menu-desk" class="d-none d-lg-block sticky-nav">
          <div class="position-relative nav-desk">
            <div class="row">
              <div class="col-md-12 align-self-center">
                <div class="ec-main-menu">
                  <ul>
                    <li class="non-drop"><a href="index.php">Home</a></li>
                    <li class="dropdown drop-list position-static">
                      <a href="javascript:void(0)" class="dropdown-arrow">Categories<i class="ecicon eci-angle-right"></i>
                      </a>
                      <ul class="mega-menu d-block">
                        <li class="d-flex">
                          <span class="bg"></span>
                          <ul class="d-block">
                            <li class="menu_title"><a href="javascript:void(0)">Fresh Vegetables</a></li>
                            <?php
                            $ret2=mysqli_query($con,"select * from tblproducts where CategoryName='78' order by rand() limit 5");
                            while ($row2=mysqli_fetch_array($ret2)) 
                            {
                              ?>
                              <li><a href="product.php?pid=<?php echo htmlentities($row2['id']);?>"><?php echo substr($row2['ProductName'],0,25);?></a>
                              </li>
                              <?php
                            }?>
                          </ul>
                          <ul class="d-block">
                            <li class="menu_title"><a href="javascript:void(0)">Fresh Fruits</a></li>
                            <?php
                            $ret3=mysqli_query($con,"select * from tblproducts where CategoryName='79' order by rand() limit 5");
                            while ($row3=mysqli_fetch_array($ret3)) 
                            {
                              ?>
                              <li><a href="product.php?pid=<?php echo htmlentities($row3['id']);?>"><?php echo substr($row3['ProductName'],0,25);?></a>
                              </li>
                              <?php
                            }?>
                          </ul>
                          <ul class="d-block">
                            <li class="menu_title"><a href="javascript:void(0)">Vegetables</a></li>
                            <?php
                            $ret4=mysqli_query($con,"select * from tblproducts where CategoryName='78' order by rand() limit 5");
                            while ($row4=mysqli_fetch_array($ret4)) 
                            {
                              ?>
                              <li><a href="product.php?pid=<?php echo htmlentities($row4['id']);?>"><?php echo substr($row4['ProductName'],0,25);?></a>
                              </li>
                              <?php
                            }?>
                          </ul>
                          <ul class="d-block">
                            <li class="menu_title"><a href="javascript:void(0)">Fruits</a>
                            </li>
                            <?php
                            $ret5=mysqli_query($con,"select * from tblproducts where CategoryName='79' order by rand() limit 5");
                            while ($row5=mysqli_fetch_array($ret5)) 
                            {
                              ?>
                              <li><a href="product.php?pid=<?php echo htmlentities($row5['id']);?>"><?php echo substr($row5['ProductName'],0,25);?></a>
                              </li>
                              <?php
                            }?>
                          </ul>
                        </li>
                      </ul>
                    </li>
                    <li class="dropdown drop-list">
                      <a href="javascript:void(0)" class="dropdown-arrow">Products<i class="ecicon eci-angle-right"></i></a>
                      <ul class="sub-menu">
                        <?php
                        $ret=mysqli_query($con,"select * from tblproducts order by rand() limit 6");
                        while ($row=mysqli_fetch_array($ret)) 
                        {
                          ?>
                          <li><a href="product.php?pid=<?php echo htmlentities($row['id']);?>"><?php echo substr($row['ProductName'],0,30);?></a></li>
                          <?php
                        }?>
                      </ul>
                    </li>
                    <li class="dropdown drop-list">
                      <a href="javascript:void(0)" class="dropdown-arrow">Pages<i class="ecicon eci-angle-right"></i></a>
                      <ul class="sub-menu">
                        <li><a href="contactus.php">Contact Us</a></li>
                        <li><a href="cart.php">Cart</a></li>
                        <li><a href="checkout.php">Checkout</a></li>
                        <li><a href="login.php">Login</a></li>
                        <li><a href="register.php">Register</a></li>
                        <li><a href="track-order.php">Track Order</a></li>
                        <li><a href="#">Terms Condition</a></li>
                        <li><a href="#">Privacy Policy</a></li>
                      </ul>
                    </li>

                    <li class="non-drop"><a href="product.php?pid=92">Offers</a></li>
                  </ul>
                </div>
              </div>
            </div>
          </div>
        </div>
        <!-- Ec Main Menu End -->
      </div>
    </div>
  </div>
  <!-- Header responsive Bottom  Start -->
  <div class="ec-header-bottom d-lg-none">
    <div class="container position-relative">
      <div class="row ">
        <div class="ec-flex">
          <!-- Ec Header Logo Start -->
          <div class="col ec-header-logo">
            <div class="header-logo">
              <a href="index.html"><img src="assets/images/logo/logo-6.png" alt="Site Logo" /><img class="dark-logo" src="assets/images/logo/dark-logo-6.png" alt="Site Logo" style="display: none;" /></a>
            </div>
          </div>
          <!-- Ec Header Logo End -->
          <div class="col ec-category-block">
            <div class="ec-category-menu">
              <div class="ec-category-toggle">
                <i class="ecicon eci-bars"></i>
                <span class="ec-category-title d-479">Category</span>
              </div>
              <div class="ec-category-content">
                <div class="ec-category-dropdown">
                  <ul class="ec-category-wrapper">
                    <li><a title="" class="ec-cat-menu-link" href="product.php?pid=94">juice & drinks</a></li>
                    <li><a title="" class="ec-cat-menu-link" href="product.php?pid=86">Fresh Fruits</a></li>
                    <li><a title="" class="ec-cat-menu-link" href="product.php?pid=90">Snack & Spices</a></li>
                    <li><a title="" class="ec-cat-menu-link" href="product.php?pid=93">Vegetables</a></li>
                  </ul>
                </div>
              </div>
            </div>
          </div>
        </div>  
        <!-- Ec Header Search Start -->
        <div class="col align-self-center ec-header-search">
          <div class="header-search">
            <form class="ec-search-group-form" action="#">
              <div class="ec-search-select-inner">
                <select name="ec-search-cat">
                  <option selected disabled>Category</option>
                  <option value="Fruits">Fruits</option>
                  <option value="Vegetables">Vegetables</option>
                  <option value="Juice">Juice</option>
                </select>
              </div>
              <input class="form-control" placeholder="Search Your Products..." type="text">
              <button class="search_submit" type="submit"><img src="assets/images/icons/search.svg"
                class="svg_img search_svg" alt="" />
              </button>
            </form>
          </div>
        </div>
        <!-- Ec Header Search End -->

      </div>
    </div>
  </div>
  <!-- Header responsive Bottom  End -->
</header>