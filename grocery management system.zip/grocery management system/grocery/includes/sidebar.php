<div class="ec-shop-leftside ec-vendor-sidebar col-lg-3 col-md-12">
  <div class="ec-sidebar-wrap">
    <!-- Sidebar Category Block -->
    <div class="ec-sidebar-block">
      <div class="ec-vendor-block">

        <div class="ec-vendor-block-items">
          <ul>
            <li><a href="user-profile.php">User Profile</a></li>
            <li><a href="user-history.php">Shopping History</a></li>
            <li><a href="wishlist.php">Wishlist</a></li>
            <li><a href="cart.php">Cart</a></li>
            <li><a href="checkout.php">Checkout</a></li>
            <li><a href="track-order.php">Track Order</a></li>
          </ul>
        </div>
      </div>
    </div>
  </div>
</div>