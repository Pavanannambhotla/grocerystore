
<?php
session_start();
error_reporting(0);
include('includes/dbconnection.php');
?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta http-equiv="x-ua-compatible" content="ie=edge" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=1.0">

  <title>Indian Grocery management system</title>
  <meta name="keywords" content="apparel, catalog, clean, ecommerce, ecommerce HTML, electronics, grocery, html eCommerce, html store, minimal, multipurpose, multipurpose ecommerce, online store, responsive ecommerce template, shops" />
  <meta name="description" content="Best ecommerce html template for single and multi vendor store.">
  <meta name="author">

  <!-- site Favicon -->
  <link rel="icon" href="assets/images/favicon/favicon.png" sizes="32x32" />
  <link rel="apple-touch-icon" href="assets/images/favicon/favicon-10.png" />
  <meta name="msapplication-TileImage" content="assets/images/favicon/favicon-10.png" />

  <!-- css Icon Font -->
  <link rel="stylesheet" href="assets/css/vendor/ecicons.min.css" />

  <!-- css All Plugins Files -->
  <link rel="stylesheet" href="assets/css/plugins/animate.css" />
  <link rel="stylesheet" href="assets/css/plugins/swiper-bundle.min.css" />
  <link rel="stylesheet" href="assets/css/plugins/jquery-ui.min.css" />
  <link rel="stylesheet" href="assets/css/plugins/countdownTimer.css" />
  <link rel="stylesheet" href="assets/css/plugins/slick.min.css" />
  <link rel="stylesheet" href="assets/css/plugins/bootstrap.css" />

  <!-- Main Style -->
  <link rel="stylesheet" href="assets/css/demo6.css" />

  <!-- SweetAlert2 -->
  <link rel="stylesheet" href="assets/sweetalert2/sweetalert2.css">
  <script src="assets/sweetalert2/sweetalert2.min.js"></script>
  <style type="text/css">
    #form_status span {
      color: #fff;
      font-size: 14px;
      font-weight: normal;
      background: #E74C3C;
      width: 100%;
      text-align: center;
      display: inline-block;
      padding: 10px 0px;
      border-radius: 3px;
      margin-bottom: 18px;
    }

    #form_status span.loading {
      color: #333;
      background: #eee;
      border-radius: 3px;
      padding: 18px 0px;
    }

  </style>
</head>
<body>
  <div id="ec-overlay"><span class="loader_img"></span></div>
  <?php
  $pid=intval($_GET['pid']);
  if(isset($_GET['pid']) && $_GET['action']=="wishlist" ){
    if(strlen($_SESSION['login'])==0)
    {   
      header('location:login.php');
    }
    else
    {
      $query=mysqli_query($con,"insert into wishlist(userId,productId) values('".$_SESSION['id']."','$pid')");
      if($query)
      {
        ?>
        <script >
          swal.fire({
            'title': 'Thank you',
            'text': 'Added successfuly',
            'icon': 'success',
            'type': 'success'
          }).then( () => {
            location.href = 'wishlist.php'
          })
        </script>
        <?php
      }
      else{
        echo "<script>alert('Something went wrong');</script>";
      }
    }
  }
  ?>

  <!-- Header start  -->
  <?php @include("includes/header.php");?>
  <!-- Header End  -->

  <!-- grocery Cart Start -->
  <?php @include("includes/shoppingcart.php");?>
  <!-- grocery Cart End -->

  <!-- Main Slider Start -->
  <div class="ec-main-slider section section-space-p-30">
    <div class="ec-slider swiper-container main-slider-nav main-slider-dot">
      <!-- Main slider -->
      <div class="swiper-wrapper">
        <div class="ec-slide-item swiper-slide d-flex slide-1">
          <div class="container align-self-center">
            <div class="row">
              <div class="col-sm-12 align-self-center">
                <div class="ec-slide-content slider-animation">
                  <h2 class="ec-slide-stitle">fresh & healthy</h2>
                  <h1 class="ec-slide-title">Organic Fruits</h1>
                  <div class="ec-slide-desc">
                    <p>starting at $ <b>35</b>.95</p>
                    <a href="product.php?pid=98" class="btn btn-lg btn-primary">Shop Now <i
                      class="ecicon eci-angle-double-right" aria-hidden="true"></i></a>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div class="ec-slide-item swiper-slide d-flex slide-2">
            <div class="container align-self-center">
              <div class="row">
                <div class="col-sm-12 align-self-center">
                  <div class="ec-slide-content slider-animation">
                    <h2 class="ec-slide-stitle">Organic & healthy</h2>
                    <h1 class="ec-slide-title">fresh vegetables</h1>
                    <div class="ec-slide-desc">
                      <p>starting at $ <b>30</b>.00</p>
                      <a href="product.php?pid=89" class="btn btn-lg btn-primary">Shop Now <i
                        class="ecicon eci-angle-double-right" aria-hidden="true"></i></a>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div class="swiper-pagination swiper-pagination-white"></div>
          <div class="swiper-buttons">
            <div class="swiper-button-next"></div>
            <div class="swiper-button-prev"></div>
          </div>
        </div>
      </div>
      <!-- Main Slider End -->

      <!--  category Section Start -->
      <section class="section ec-category-section section-space-pb">
        <div class="container-fluid">
          <div class="row d-none">
            <div class="col-md-12">
              <div class="section-title">
                <h2 class="ec-title">Top Category</h2>
              </div>
            </div>
          </div>
          <div class="row margin-minus-b-15 margin-minus-t-15">
            <div id="ec-cat-slider">
              <div class="ec_cat_content ec_cat_content_1 col-sm-12 col-md-6 col-lg-3">
                <div class="ec_cat_inner ec_cat_inner-1">
                  <div class="ec-category-image">
                    <img src="assets/images/icons/drink-6.svg" class="svg_img" alt="drink" />
                  </div>
                  <div class="ec-category-desc">
                    <h3>juice & drinks</h3>
                    <ul>
                      <li><a href="#">Energy Drink</a></li>
                      <li><a href="#">Ice Tea</a></li>
                      <li><a href="#">Milk Shake</a></li>
                      <li><a href="#">Soft Drink</a></li>
                    </ul>
                    <a href="#" class="cat-show-all">Show All <i class="ecicon eci-angle-double-right"
                      aria-hidden="true"></i>
                    </a>
                  </div>
                </div>
              </div>
              <div class="ec_cat_content ec_cat_content_2 col-sm-12 col-md-6 col-lg-3">
                <div class="ec_cat_inner ec_cat_inner-2">
                  <div class="ec-category-image">
                    <img src="assets/images/icons/fruit-6.svg" class="svg_img" alt="drink" />
                  </div>
                  <div class="ec-category-desc">
                    <h3>Fresh Fruits</h3>
                    <ul>
                      <li><a href="#">Graps</a></li>
                      <li><a href="#">Apple</a></li>
                      <li><a href="#">Cherry</a></li>
                      <li><a href="#">Mango</a></li>
                    </ul>
                    <a href="#" class="cat-show-all">Show All <i class="ecicon eci-angle-double-right"
                      aria-hidden="true"></i>
                    </a>
                  </div>
                </div>
              </div>
              <div class="ec_cat_content ec_cat_content_3 col-sm-12 col-md-6 col-lg-3">
                <div class="ec_cat_inner ec_cat_inner-3">
                  <div class="ec-category-image">
                    <img src="assets/images/icons/pack-6.svg" class="svg_img" alt="drink" />
                  </div>
                  <div class="ec-category-desc">
                    <h3>Snack & Spice</h3>
                    <ul>
                      <li><a href="#">Cheerios</a></li>
                      <li><a href="#">potato chips</a></li>
                      <li><a href="#">french fries</a></li>
                      <li><a href="#">cookies</a></li>
                    </ul>
                    <a href="#" class="cat-show-all">Show All <i class="ecicon eci-angle-double-right"
                      aria-hidden="true"></i>
                    </a>
                  </div>
                </div>
              </div>
              <div class="ec_cat_content ec_cat_content_4 col-sm-12 col-md-6 col-lg-3">
                <div class="ec_cat_inner ec_cat_inner-4">
                  <div class="ec-category-image">
                    <img src="assets/images/icons/vege-6.svg" class="svg_img" alt="drink" />
                  </div>
                  <div class="ec-category-desc">
                    <h3>Vegetables</h3>
                    <ul>
                      <li><a href="#">Broccoli</a></li>
                      <li><a href="#">coriender</a></li>
                      <li><a href="#">Cucumber</a></li>
                      <li><a href="#">pupmkin</a></li>
                    </ul>
                    <a href="#" class="cat-show-all">Show All <i class="ecicon eci-angle-double-right"
                      aria-hidden="true"></i>
                    </a>
                  </div>
                </div>
              </div>
              <div class="ec_cat_content ec_cat_content_5 col-sm-12 col-md-6 col-lg-3">
                <div class="ec_cat_inner ec_cat_inner-5">
                  <div class="ec-category-image">
                    <img src="assets/images/icons/dairy-6.svg" class="svg_img" alt="drink" />
                  </div>
                  <div class="ec-category-desc">
                    <h3>Dairy & Milk</h3>
                    <ul>
                      <li><a href="#">Ice Cream</a></li>
                      <li><a href="#">Milk</a></li>
                      <li><a href="#">pastries</a></li>
                      <li><a href="#">cupcake</a></li>
                    </ul>
                    <a href="#" class="cat-show-all">Show All <i class="ecicon eci-angle-double-right"
                      aria-hidden="true"></i>
                    </a>
                  </div>
                </div>
              </div>
              <div class="ec_cat_content ec_cat_content_6 col-sm-12 col-md-6 col-lg-3">
                <div class="ec_cat_inner ec_cat_inner-6">
                  <div class="ec-category-image">
                    <img src="assets/images/icons/dish-6.svg" class="svg_img" alt="drink" />
                  </div>
                  <div class="ec-category-desc">
                    <h3>Sea food</h3>
                    <ul>
                      <li><a href="#">Shrimp</a></li>
                      <li><a href="#">mussel</a></li>
                      <li><a href="#">lobster</a></li>
                      <li><a href="#">Scallop</a></li>
                    </ul>
                    <a href="#" class="cat-show-all">Show All <i class="ecicon eci-angle-double-right"
                      aria-hidden="true"></i>
                    </a>
                  </div>
                </div>
              </div>
              <div class="ec_cat_content ec_cat_content_7 col-sm-12 col-md-6 col-lg-3">
                <div class="ec_cat_inner ec_cat_inner-7">
                  <div class="ec-category-image">
                    <img src="assets/images/icons/bak-6.svg" class="svg_img" alt="drink" />
                  </div>
                  <div class="ec-category-desc">
                    <h3>bakery</h3>
                    <ul>
                      <li><a href="#">donut</a></li>
                      <li><a href="#">cream bun</a></li>
                      <li><a href="#">jam roll</a></li>
                      <li><a href="#">muruk</a></li>
                    </ul>
                    <a href="#" class="cat-show-all">Show All <i class="ecicon eci-angle-double-right"
                      aria-hidden="true"></i>
                    </a>
                  </div>
                </div>
              </div>
              <div class="ec_cat_content ec_cat_content_8 col-sm-12 col-md-6 col-lg-3">
                <div class="ec_cat_inner ec_cat_inner-8">
                  <div class="ec-category-image">
                    <img src="assets/images/icons/vege-6.svg" class="svg_img" alt="drink" />
                  </div>
                  <div class="ec-category-desc">
                    <h3>Vegetables</h3>
                    <ul>
                      <li><a href="#">Broccoli</a></li>
                      <li><a href="#">coriender</a></li>
                      <li><a href="#">Cucumber</a></li>
                      <li><a href="#">pupmkin</a></li>
                    </ul>
                    <a href="#" class="cat-show-all">Show All <i class="ecicon eci-angle-double-right"
                      aria-hidden="true"></i>
                    </a>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
      <!--category Section End -->

      <!--  offer Section Start -->
      <section class="section ec-offer-secti section-space-m">
        <h2 class="d-none">Offer</h2>
        <div class="container">
          <div class="row ec-pos ec-ofr-bnr" data-animation="fadeIn">
            <div class="ec-offer-inner">
              <div class="col-xl-5 col-md-6 col-sm-6 align-self-center ec-offer-content">
                <h3 class="ec-offer-stitle">Start Today !</h3>
                <h2 class="ec-offer-title">Fresh Vegetables & Fruits</h2>
                <span class="ec-offer-desc">Make your first order to get free home delivery!!!</span>
                <span class="ec-offer-btn">
                  <a href="product.php?pid=85" class="btn btn-lg btn-primary">Shop Now <i
                    class="ecicon eci-angle-double-right" aria-hidden="true"></i>
                  </a>
                </span>
              </div>
            </div>
          </div>
        </div>
      </section>
      <!-- offer Section End -->

      <!-- Product tab Area Start -->
      <section class="section ec-product-tab section-space-p">
        <div class="container" data-animation="fadeIn">
          <div class="row">
            <div class="col-md-12">
              <div class="section-title">
                <h2 class="ec-title">New Products</h2>
              </div>
            </div>

            <!-- Tab Start -->
            <div class="col-md-12 ec-pro-tab">
              <ul class="ec-pro-tab-nav nav justify-content-end">
                <li class="nav-item"><a class="nav-link active" data-bs-toggle="tab"
                  href="#all">All</a>
                </li>
                <li class="nav-item"><a class="nav-link" data-bs-toggle="tab" href="#snack">Snack & Spices</a>
                </li>
                <li class="nav-item"><a class="nav-link" data-bs-toggle="tab"
                  href="#veg">Vegetables</a>
                </li>
                <li class="nav-item"><a class="nav-link" data-bs-toggle="tab"
                  href="#fruit">Fruits</a>
                </li>
              </ul>
            </div>
            <!-- Tab End -->
          </div>
          <div class="row margin-minus-b-15">
            <div class="col">
              <div class="tab-content">
                <!-- 1st Product tab start -->
                <div class="tab-pane fade show active" id="all">
                  <div class="row">
                    <?php
                    $ret=mysqli_query($con,"select * from tblproducts where Status='New' order by rand() limit 10");
                    while ($row=mysqli_fetch_array($ret))

                    {
                      ?>
                      <div class="col-lg-3 col-md-6 col-sm-6 col-xs-6 col-5 ec-product-content">
                        <div class="ec-product-inner">
                          <div class="ec-pro-image-outer">
                            <div class="ec-pro-image">
                              <a href="product.php?pid=<?php echo htmlentities($row['id']);?>" class="image">
                                <span class="label veg">
                                  <span class="dot"></span>
                                </span>
                                <img class="main-image"
                                src="admin/productimages/<?php echo htmlentities($row['ProductImage']);?>" alt="Product" />
                                <img class="hover-image"
                                src="admin/productimages/<?php echo htmlentities($row['ProductImage2']);?>" alt="Product" />
                              </a>
                              <span class="flags">
                                <span class="new">New</span>
                              </span>
                              <div class="ec-pro-actions">
                                <a href="index.php?pid=<?php echo htmlentities($row['id'])?>&&action=wishlist" class="ec-btn-group wishlist" title="Wishlist"><img src="assets/images/icons/pro_wishlist.svg"class="svg_img pro_svg" alt="" /></a>
                                <a href="addcart.php?page=product&action=add&id=<?php echo $row['id']; ?>"  title="Add To Cart" class="ec-btn-group add-to-cart"><img src="assets/images/icons/pro_cart.svg"
                                  class="svg_img pro_svg" alt="" />
                                </a>
                              </div>
                            </div>
                          </div>
                          <div class="ec-pro-content">
                            <a href="product.php?pid=<?php echo htmlentities($row['id']);?>">
                              <?php
                              $category=$row['CategoryName'];
                              $ret2=mysqli_query($con,"select * from tblcategory where id=$category ");
                              while ($row2=mysqli_fetch_array($ret2))
                              {
                                ?>
                                <h6 class="ec-pro-stitle"><?php echo htmlentities($row2['CategoryName']);?></h6>
                                <?php
                              }
                              ?>
                            </a>
                            <h5 class="ec-pro-title"><a href="product.php?pid=<?php echo htmlentities($row['id']);?>"><?php echo htmlentities($row['ProductName']);?></a>
                            </h5>
                            <div class="ec-pro-rat-price">
                              <span class="ec-pro-rating">
                                <i class="ecicon eci-star fill"></i>
                                <i class="ecicon eci-star fill"></i>
                                <i class="ecicon eci-star"></i>
                                <i class="ecicon eci-star"></i>
                                <i class="ecicon eci-star"></i>
                              </span>
                              <span class="ec-price">
                                <span class="new-price">$&nbsp;<?php echo htmlentities(number_format($row['PriceBefore'], 0, '.', ','));?></span>
                                <span class="old-price">$&nbsp;<?php echo htmlentities(number_format($row['ProductPrice'], 0, '.', ','));?></span>
                              </span>
                            </div>
                          </div>
                        </div>
                      </div>
                      <?php
                    }
                    ?>
                  </div>
                </div>
                <!-- ec 1st Product tab end -->
                <!-- ec 2nd Product tab start -->
                <div class="tab-pane fade" id="snack">
                  <div class="row">
                    <?php
                    $ret=mysqli_query($con,"select * from tblproducts where Status='New' order by rand() limit 10");
                    while ($row=mysqli_fetch_array($ret))

                    {
                      ?>
                      <div class="col-lg-3 col-md-6 col-sm-6 col-xs-6 col-5 ec-product-content">
                        <div class="ec-product-inner">
                          <div class="ec-pro-image-outer">
                            <div class="ec-pro-image">
                              <a href="product.php?pid=<?php echo htmlentities($row['id']);?>" class="image">
                                <span class="label veg">
                                  <span class="dot"></span>
                                </span>
                                <img class="main-image"
                                src="admin/productimages/<?php echo htmlentities($row['ProductImage']);?>" alt="Product" />
                                <img class="hover-image"
                                src="admin/productimages/<?php echo htmlentities($row['ProductImage2']);?>" alt="Product" />
                              </a>
                              <span class="flags">
                                <span class="sale">Sale</span>
                              </span>
                              <div class="ec-pro-actions">
                                <a href="index.php?pid=<?php echo htmlentities($row['id'])?>&&action=wishlist" class="ec-btn-group wishlist" title="Wishlist"><img src="assets/images/icons/pro_wishlist.svg"class="svg_img pro_svg" alt="" /></a>
                                <a href="addcart.php?page=product&action=add&id=<?php echo $row['id']; ?>"  title="Add To Cart" class="ec-btn-group add-to-cart"><img src="assets/images/icons/pro_cart.svg"
                                  class="svg_img pro_svg" alt="" />
                                </a>
                              </div>
                            </div>
                          </div>
                          <div class="ec-pro-content">
                            <a href="product.php?pid=<?php echo htmlentities($row['id']);?>">
                              <?php
                              $category=$row['CategoryName'];
                              $ret2=mysqli_query($con,"select * from tblcategory where id=$category ");
                              while ($row2=mysqli_fetch_array($ret2))
                              {
                                ?>
                                <h6 class="ec-pro-stitle"><?php echo htmlentities($row2['CategoryName']);?></h6>
                                <?php
                              }
                              ?>
                            </a>
                            <h5 class="ec-pro-title"><a href="product.php?pid=<?php echo htmlentities($row['id']);?>"><?php echo htmlentities($row['ProductName']);?></a></h5>
                            <div class="ec-pro-rat-price">
                              <span class="ec-pro-rating">
                                <i class="ecicon eci-star fill"></i>
                                <i class="ecicon eci-star fill"></i>
                                <i class="ecicon eci-star"></i>
                                <i class="ecicon eci-star"></i>
                                <i class="ecicon eci-star"></i>
                              </span>
                              <span class="ec-price">
                                <span class="new-price">$&nbsp;<?php echo htmlentities(number_format($row['PriceBefore'], 0, '.', ','));?></span>
                                <span class="old-price">$&nbsp;<?php echo htmlentities(number_format($row['ProductPrice'], 0, '.', ','));?></span>
                              </span>
                            </div>
                          </div>
                        </div>
                      </div>
                      <?php
                    }
                    ?>
                  </div>
                </div>
                <!-- ec 2nd Product tab end -->
                <!-- ec 3rd Product tab start -->
                <div class="tab-pane fade" id="veg">
                  <div class="row">
                    <?php
                    $ret=mysqli_query($con,"select * from tblproducts where Status='New' order by rand() limit 10");
                    while ($row=mysqli_fetch_array($ret))

                    {
                      ?>
                      <div class="col-lg-3 col-md-6 col-sm-6 col-xs-6 col-5 ec-product-content">
                        <div class="ec-product-inner">
                          <div class="ec-pro-image-outer">
                            <div class="ec-pro-image">
                              <a href="product.php?pid=<?php echo htmlentities($row['id']);?>" class="image">
                                <span class="label veg">
                                  <span class="dot"></span>
                                </span>
                                <img class="main-image" src="admin/productimages/<?php echo htmlentities($row['ProductImage']);?>" alt="Product" />
                                <img class="hover-image"
                                src="admin/productimages/<?php echo htmlentities($row['ProductImage2']);?>" alt="Product" />
                              </a>
                              <span class="flags">
                                <span class="new">New</span>
                              </span>
                              <div class="ec-pro-actions">
                                <a href="index.php?pid=<?php echo htmlentities($row['id'])?>&&action=wishlist" class="ec-btn-group wishlist" title="Wishlist">
                                  <img src="assets/images/icons/pro_wishlist.svg"
                                  class="svg_img pro_svg" alt="" />
                                </a>
                                <a href="addcart.php?page=product&action=add&id=<?php echo $row['id']; ?>"  title="Add To Cart" class="ec-btn-group add-to-cart"><img src="assets/images/icons/pro_cart.svg"
                                  class="svg_img pro_svg" alt="" />
                                </a>
                              </div>
                            </div>
                          </div>
                          <div class="ec-pro-content">
                            <a href="product.php?pid=<?php echo htmlentities($row['id']);?>">
                              <?php
                              $category=$row['CategoryName'];
                              $ret2=mysqli_query($con,"select * from tblcategory where id=$category ");
                              while ($row2=mysqli_fetch_array($ret2))
                              {
                                ?>
                                <h6 class="ec-pro-stitle"><?php echo htmlentities($row2['CategoryName']);?></h6>
                                <?php
                              }
                              ?>
                            </a>
                            <h5 class="ec-pro-title"><a href="product.php?pid=<?php echo htmlentities($row['id']);?>"><?php echo htmlentities($row['ProductName']);?></a></h5>
                            <div class="ec-pro-rat-price">
                              <span class="ec-pro-rating">
                                <i class="ecicon eci-star fill"></i>
                                <i class="ecicon eci-star fill"></i>
                                <i class="ecicon eci-star"></i>
                                <i class="ecicon eci-star"></i>
                                <i class="ecicon eci-star"></i>
                              </span>
                              <span class="ec-price">
                                <span class="new-price">$&nbsp;<?php echo htmlentities(number_format($row['PriceBefore'], 0, '.', ','));?></span>
                                <span class="old-price">$&nbsp;<?php echo htmlentities(number_format($row['ProductPrice'], 0, '.', ','));?></span>
                              </span>
                            </div>
                          </div>
                        </div>
                      </div>
                      <?php
                    }
                    ?>
                  </div>
                </div>
                <!-- ec 3rd Product tab end -->
                <!-- ec 3rd Product tab start -->
                <div class="tab-pane fade" id="fruit">
                  <div class="row">
                    <?php
                    $ret=mysqli_query($con,"select * from tblproducts where Status='Special' order by rand() limit 10");
                    while ($row=mysqli_fetch_array($ret))

                    {
                      ?>
                      <div class="col-lg-3 col-md-6 col-sm-6 col-xs-6 col-5 ec-product-content">
                        <div class="ec-product-inner">
                          <div class="ec-pro-image-outer">
                            <div class="ec-pro-image">
                              <a href="product.php?pid=<?php echo htmlentities($row['id']);?>" class="image">
                                <span class="label veg">
                                  <span class="dot"></span>
                                </span>
                                <img class="main-image"
                                src="admin/productimages/<?php echo htmlentities($row['ProductImage']);?>" alt="Product" />
                                <img class="hover-image"
                                src="admin/productimages/<?php echo htmlentities($row['ProductImage2']);?>" alt="Product" />
                              </a>
                              <span class="flags">
                                <span class="new">New</span>
                              </span>
                              <div class="ec-pro-actions">
                                <a href="index.php?pid=<?php echo htmlentities($row['id'])?>&&action=wishlist" class="ec-btn-group wishlist" title="Wishlist"><img src="assets/images/icons/pro_wishlist.svg" class="svg_img pro_svg" alt="" /></a>
                                <a href="addcart.php?page=product&action=add&id=<?php echo $row['id']; ?>"  title="Add To Cart" class="ec-btn-group add-to-cart"><img src="assets/images/icons/pro_cart.svg"
                                  class="svg_img pro_svg" alt="" />
                                </a>
                              </div>
                            </div>
                          </div>
                          <div class="ec-pro-content">
                            <a href="product.php?pid=<?php echo htmlentities($row['id']);?>">
                              <?php
                              $category=$row['CategoryName'];
                              $ret2=mysqli_query($con,"select * from tblcategory where id=$category ");
                              while ($row2=mysqli_fetch_array($ret2))
                              {
                                ?>
                                <h6 class="ec-pro-stitle"><?php echo htmlentities($row2['CategoryName']);?></h6>
                                <?php
                              }
                              ?>
                            </a>
                            <h5 class="ec-pro-title"><a href="product.php?pid=<?php echo htmlentities($row['id']);?>"><?php echo htmlentities($row['ProductName']);?></a></h5>
                            <div class="ec-pro-rat-price">
                              <span class="ec-pro-rating">
                                <i class="ecicon eci-star fill"></i>
                                <i class="ecicon eci-star fill"></i>
                                <i class="ecicon eci-star"></i>
                                <i class="ecicon eci-star"></i>
                                <i class="ecicon eci-star"></i>
                              </span>
                              <span class="ec-price">
                                <span class="new-price">$&nbsp;<?php echo htmlentities(number_format($row['PriceBefore'], 0, '.', ','));?></span>
                                <span class="old-price">$&nbsp;<?php echo htmlentities(number_format($row['ProductPrice'], 0, '.', ','));?></span>
                              </span>
                            </div>
                          </div>
                        </div>
                      </div>
                      <?php
                    }
                    ?>
                  </div>
                </div>
                <!-- ec 3rd Product tab end -->
              </div>
            </div>
          </div>
        </div>
      </section>
      <!-- ec Product tab Area End -->

      <!-- ec Banner Section Start -->
      <section class="ec-banner section section-space-p">
        <h2 class="d-none">Banner</h2>
        <div class="container">
          <div class="row">
            <div class="ec-banner-inner">
              <div class="ec-banner-block ec-banner-block-1" data-animation="slideInRight">
                <div class="banner-block">
                  <img src="assets/images/banner/22.jpg" alt="" />
                  <div class="banner-content">
                    <div class="banner-text">
                      <span class="ec-banner-disc">25% discount</span>
                      <span class="ec-banner-title">Vegetables & Fruits</span>
                      <span class="ec-banner-stitle">Starting @ $10</span>
                    </div>
                    <span class="ec-banner-btn"><a href="product.php?pid=89">Shop Now <i
                      class="ecicon eci-angle-double-right" aria-hidden="true"></i></a>
                    </span>
                  </div>
                </div>
              </div>
              <div class="ec-banner-block ec-banner-block-2" data-animation="fadeIn">
                <div class="banner-block">
                  <img src="assets/images/banner/23.jpg" alt="" />
                  <div class="banner-content">
                    <div class="banner-text">
                      <span class="ec-banner-disc">10% discount</span>
                      <span class="ec-banner-title">Juice & Passion Fruit</span>
                      <span class="ec-banner-stitle">Starting @ $20</span>
                    </div>
                    <span class="ec-banner-btn"><a href="product.php?pid=96">Shop Now <i
                      class="ecicon eci-angle-double-right" aria-hidden="true"></i></a>
                    </span>
                  </div>
                </div>
              </div>
              <div class="ec-banner-block ec-banner-block-3" data-animation="slideInLeft">
                <div class="banner-block">
                  <img src="assets/images/banner/24.jpg" alt="" />
                  <div class="banner-content">
                    <div class="banner-text">
                      <span class="ec-banner-disc">Upto 20% off</span>
                      <span class="ec-banner-title">Quality Jack fruit</span>
                      <span class="ec-banner-stitle">Starting @ $50</span>
                    </div>
                    <span class="ec-banner-btn"><a href="product.php?pid=102">Shop Now <i
                      class="ecicon eci-angle-double-right" aria-hidden="true"></i></a>
                    </span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
      <!-- ec Banner Section End -->

      <!--  Day of deal & service Section Start -->
      <section class="section ec-ser-spe-section section-space-p">
        <div class="container" data-animation="fadeIn">
          <div class="row">
            <!--  Special Section Start -->
            <div class="ec-spe-section col-lg-9 col-md-9 col-sm-9 sectopn-spc-mb">
              <div class="col-md-12">
                <div class="section-title">
                  <h2 class="ec-title">Deal of the day</h2>
                </div>
              </div>

              <div class="ec-spe-products">
                <div class="ec-spe-product">
                  <div class="ec-spe-pro-inner">
                    <div class="ec-spe-pro-image-outer col-md-6 col-sm-12">
                      <div class="ec-spe-pro-image">
                        <img class="img-responsive" src="assets/images/product-image/orange3.jpg" alt="">                                                                              
                      </div>
                    </div>
                    <div class="ec-spe-pro-content col-md-6 col-sm-12">
                      <div class="ec-spe-pro-rating">
                        <span class="ec-spe-rating-icon">
                          <i class="ecicon eci-star fill"></i>
                          <i class="ecicon eci-star fill"></i>
                          <i class="ecicon eci-star fill"></i>
                          <i class="ecicon eci-star"></i>
                          <i class="ecicon eci-star"></i>
                        </span>
                      </div>
                      <h5 class="ec-spe-pro-title"><a href="product.php?pid=94">Organic Mango 10kg Box</a></h5>
                      <div class="ec-spe-pro-desc">Lorem ipsum dolor sit amet consectetur Lorem ipsum
                      dolor dolor sit amet consectetur Lorem ipsum dolor</div>
                      <div class="ec-spe-price">
                        <span class="new-price">$150.00</span>
                        <span class="old-price">$180.00</span>
                      </div>
                      <div class="ec-spe-pro-btn">
                        <a href="addcart.php?page=product&action=add&id=94" class="btn btn-lg btn-primary">Add To Cart</a>
                      </div>
                      <div class="ec-spe-pro-progress">
                        <span class="ec-spe-pro-progress-desc"><span>Already Sold:
                          <b>12</b></span><span>Available: <b>20</b></span>
                        </span>
                        <span class="ec-spe-pro-progressbar">

                        </span>
                      </div>
                      <div class="countdowntimer">
                        <span class="ec-spe-count-desc"> Hurry Up! Offer ends in:</span>
                        <span id="ec-spe-count-1"></span>
                      </div>

                    </div>
                  </div>
                </div>
                <div class="ec-spe-product">
                  <div class="ec-spe-pro-inner">
                    <div class="ec-spe-pro-image-outer col-md-6 col-sm-12">
                      <div class="ec-spe-pro-image">
                        <img class="img-responsive"
                        src="assets/images/product-image/78_1.jpg" alt="">
                      </div>
                    </div>
                    <div class="ec-spe-pro-content col-md-6 col-sm-12">
                      <div class="ec-spe-pro-rating">
                        <span class="ec-spe-rating-icon">
                          <i class="ecicon eci-star fill"></i>
                          <i class="ecicon eci-star fill"></i>
                          <i class="ecicon eci-star fill"></i>
                          <i class="ecicon eci-star"></i>
                          <i class="ecicon eci-star"></i>
                        </span>
                      </div>
                      <h5 class="ec-spe-pro-title"><a href="product.php?pid=101">Fresh organic Apple 12 Pcs</a></h5>
                      <div class="ec-spe-pro-desc">Lorem ipsum dolor sit amet consectetur Lorem ipsum
                      dolor dolor sit amet consectetur Lorem ipsum dolor</div>
                      <div class="ec-spe-price">
                        <span class="new-price">$199.00</span>
                        <span class="old-price">$200.00</span>
                      </div>
                      <div class="ec-spe-pro-btn">
                        <a href="addcart.php?page=product&action=add&id=101" class="btn btn-lg btn-primary">Add To Cart</a>
                      </div>
                      <div class="ec-spe-pro-progress">
                        <span class="ec-spe-pro-progress-desc"><span>Already Sold:
                          <b>20</b></span><span>Available: <b>40</b></span>
                        </span>
                        <span class="ec-spe-pro-progressbar">

                        </span>
                      </div>
                      <div class="countdowntimer">
                        <span class="ec-spe-count-desc"> Hurry Up! Offer ends in:</span>
                        <span id="ec-spe-count-2"></span>
                      </div>

                    </div>
                  </div>
                </div>
              </div>
            </div>
            <!--  Testimonial & Special Section End -->

            <!--  services Section Start -->
            <div class="ec-services-section col-lg-3 col-md-3 col-sm-3">
              <div class="col-md-12">
                <div class="section-title">
                  <h2 class="ec-title">Our Services</h2>
                </div>
              </div>
              <div class="ec_ser_block">
                <div class="ec_ser_content ec_ser_content_1 col-sm-12">
                  <div class="ec_ser_inner">
                    <div class="ec-service-image">
                      <img src="assets/images/icons/service_4_1.svg" class="svg_img ser_svg" alt="" />
                    </div>
                    <div class="ec-service-desc">
                      <h2>Worldwide Delivery</h2>
                      <p>For Order Over $100</p>
                    </div>
                  </div>
                </div>
                <div class="ec_ser_content ec_ser_content_2 col-sm-12">
                  <div class="ec_ser_inner">
                    <div class="ec-service-image">
                      <img src="assets/images/icons/service_4_2.svg" class="svg_img ser_svg" alt="" />
                    </div>
                    <div class="ec-service-desc">
                      <h2>Next Day delivery</h2>
                      <p>UK Orders Only</p>
                    </div>
                  </div>
                </div>
                <div class="ec_ser_content ec_ser_content_3 col-sm-12">
                  <div class="ec_ser_inner">
                    <div class="ec-service-image">
                      <img src="assets/images/icons/service_4_3.svg" class="svg_img ser_svg" alt="" />
                    </div>
                    <div class="ec-service-desc">
                      <h2>Best Online Support</h2>
                      <p>Hours: 8AM -11PM</p>
                    </div>
                  </div>
                </div>
                <div class="ec_ser_content ec_ser_content_4 col-sm-12">
                  <div class="ec_ser_inner">
                    <div class="ec-service-image">
                      <img src="assets/images/icons/service_4_4.svg" class="svg_img ser_svg" alt="" />
                    </div>
                    <div class="ec-service-desc">
                      <h2>Return Policy</h2>
                      <p>Easy & Free Return</p>
                    </div>
                  </div>
                </div>
                <div class="ec_ser_content ec_ser_content_5 col-sm-12">
                  <div class="ec_ser_inner">
                    <div class="ec-service-image">
                      <img src="assets/images/icons/service_4_5.svg" class="svg_img ser_svg" alt="" />
                    </div>
                    <div class="ec-service-desc">
                      <h2>30% money back</h2>
                      <p>For Order Over $100</p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <!--services Section End -->

      </section>
      <!--  End Day of deal & service Section Start -->

      <!-- Testimonial & Ec new product section -->
      <section class="section ec-new-test-product section-space-p">
        <div class="container">
          <div class="row">
            <!-- ec testimonial Start -->
            <div class="ec-test-section col-lg-3 col-md-6 col-sm-12 col-xs-6 sectopn-spc-mb" data-animation="slideInRight">
              <div class="col-md-12">
                <div class="section-title">
                  <h2 class="ec-title">Testimonial</h2>
                </div>
              </div>
              <div class="ec-test-outer">
                <ul id="ec-testimonial-slider">
                  <li class="ec-test-item">
                    <div class="ec-test-inner">
                      <div class="ec-test-img">
                        <img alt="testimonial" title="testimonial"
                        src="assets/images/testimonial/1.jpg" />
                      </div>
                      <div class="ec-test-content">
                        <div class="ec-test-name">mark jofferson</div>
                        <div class="ec-test-designation">- CEO & Founder Invision</div>
                        <div class="ec-test-divider">
                          <img src="assets/images/testimonial/quotes.svg" class="svg_img test_svg"
                          alt="" />
                        </div>
                        <div class="ec-test-desc">Lorem ipsum dolor sit amet consectetur Lorem ipsum
                          dolor dolor sit amet.
                        </div>
                      </div>
                    </div>
                  </li>
                  <li class="ec-test-item">
                    <div class="ec-test-inner">
                      <div class="ec-test-img">
                        <img alt="testimonial" title="testimonial"
                        src="assets/images/testimonial/2.jpg" />
                      </div>
                      <div class="ec-test-content">
                        <div class="ec-test-name">mark jofferson</div>
                        <div class="ec-test-designation">- CEO & Founder Invision</div>
                        <div class="ec-test-divider">
                          <img src="assets/images/testimonial/quotes.svg" class="svg_img test_svg"
                          alt="" />
                        </div>
                        <div class="ec-test-desc">Lorem ipsum dolor sit amet consectetur Lorem ipsum
                          dolor dolor sit amet.
                        </div>
                      </div>
                    </div>
                  </li>
                  <li class="ec-test-item">
                    <div class="ec-test-inner">
                      <div class="ec-test-img">
                        <img alt="testimonial" title="testimonial"
                        src="assets/images/testimonial/3.jpg" />
                      </div>
                      <div class="ec-test-content">
                        <div class="ec-test-name">mark jofferson</div>
                        <div class="ec-test-designation">- CEO & Founder Invision</div>
                        <div class="ec-test-divider">
                          <img src="assets/images/testimonial/quotes.svg" class="svg_img test_svg"
                          alt="" />
                        </div>
                        <div class="ec-test-desc">Lorem ipsum dolor sit amet consectetur Lorem ipsum
                          dolor dolor sit amet.
                        </div>
                      </div>
                    </div>
                  </li>
                </ul>
              </div>
            </div>
            <!-- ec testimonial end -->
            <!-- ec New Arrivals -->
            <div class="col-lg-3 col-md-6 col-sm-12 col-xs-6 ec-all-product-content ec-new-product-content margin-b-30" data-animation="slideInRight">
              <div class="col-md-12">
                <div class="section-title">
                  <h2 class="ec-title">New Arrivals</h2>
                </div>
              </div>
              <div class="ec-new-slider">
                <?php
                $ret=mysqli_query($con,"select * from tblproducts where Status='New' order by rand()");
                while ($row=mysqli_fetch_array($ret)) 
                {
                  $discount=$row['ProductDiscount'];
                  ?>
                  <div class="col-sm-12 ec-all-product-block">
                    <div class="ec-all-product-inner">
                      <div class="ec-pro-image-outer">
                        <div class="ec-pro-image">
                          <a href="product.php?pid=<?php echo htmlentities($row['id']);?>" class="image">
                            <img class="main-image" src="admin/productimages/<?php echo htmlentities($row['ProductImage']);?>"
                            alt="Product" />
                          </a>
                        </div>
                      </div>
                      <div class="ec-pro-content">
                        <h5 class="ec-pro-title"><a href="product.php?pid=<?php echo htmlentities($row['id']);?>"><?php echo htmlentities($row['ProductName']);?></a></h5>
                        <h6 class="ec-pro-stitle">
                          <?php
                          $category=$row['CategoryName'];
                          $ret2=mysqli_query($con,"select * from tblcategory where id=$category ");
                          while ($row2=mysqli_fetch_array($ret2))
                          {
                            ?>
                            <a href="product.php?pid=<?php echo htmlentities($row['id']);?>"><?php echo htmlentities($row2['CategoryName']);?></a>
                            <?php
                          }
                          ?>

                        </h6>
                        <div class="ec-pro-rat-price">
                          <div class="ec-pro-rat-pri-inner">
                            <span class="ec-price">
                              <span class="new-price">$&nbsp;<?php echo htmlentities(number_format($row['ProductPrice'], 0, '.', ','));?></span>
                              <span class="old-price">$&nbsp;<?php echo htmlentities(number_format($row['ProductPrice'], 0, '.', ','));?></span>
                              <span class="qty">- <?php echo htmlentities($row['Quantity']);?></span>
                            </span>
                          </div>
                        </div>
                      </div>
                      <span class="label veg" title="Veg">
                        <span class="dot"></span>
                      </span>
                    </div>
                  </div>
                  <?php
                }
                ?>
              </div>
            </div>
            <!-- ec Top Selling -->
            <div class="col-lg-3 col-md-6 col-sm-12 col-xs-6 ec-all-product-content ec-new-product-content margin-b-30" data-animation="slideInLeft">
              <div class="col-md-12">
                <div class="section-title">
                  <h2 class="ec-title">Top Selling</h2>
                </div>
              </div>
              <div class="ec-new-slider">
                <?php
                $ret=mysqli_query($con,"select * from tblproducts order by rand()");
                while ($row=mysqli_fetch_array($ret)) 
                {
                  $discount=$row['ProductDiscount'];
                  ?>
                  <div class="col-sm-12 ec-all-product-block">
                    <div class="ec-all-product-inner">
                      <div class="ec-pro-image-outer">
                        <div class="ec-pro-image">
                          <a href="product.php?pid=<?php echo htmlentities($row['id']);?>" class="image">
                            <img class="main-image" src="admin/productimages/<?php echo htmlentities($row['ProductImage']);?>"
                            alt="Product" />
                          </a>
                        </div>
                      </div>
                      <div class="ec-pro-content">
                        <h5 class="ec-pro-title"><a href="product.php?pid=<?php echo htmlentities($row['id']);?>"><?php echo htmlentities($row['ProductName']);?></a></h5>
                        <h6 class="ec-pro-stitle">
                          <?php
                          $category=$row['CategoryName'];
                          $ret2=mysqli_query($con,"select * from tblcategory where id=$category ");
                          while ($row2=mysqli_fetch_array($ret2))
                          {
                            ?>
                            <a href="shop-left-sidebar-col-3.html"><?php echo htmlentities($row2['CategoryName']);?></a>
                            <?php
                          }
                          ?>

                        </h6>
                        <div class="ec-pro-rat-price">
                          <div class="ec-pro-rat-pri-inner">
                            <span class="ec-price">
                              <span class="new-price">$&nbsp;<?php echo htmlentities(number_format($row['ProductPrice'], 0, '.', ','));?></span>
                              <span class="old-price">$&nbsp;<?php echo htmlentities(number_format($row['ProductPrice'], 0, '.', ','));?></span>
                              <span class="qty">- <?php echo htmlentities($row['Quantity']);?></span>
                            </span>
                          </div>
                        </div>
                      </div>
                      <span class="label veg" title="Veg">
                        <span class="dot"></span>
                      </span>
                    </div>
                  </div>
                  <?php
                }
                ?>
              </div>
            </div>
            <!-- ec Top Rated -->
            <div class="col-lg-3 col-md-6 col-sm-12 col-xs-6 ec-all-product-content ec-new-product-content" data-animation="slideInLeft">
              <div class="col-md-12">
                <div class="section-title">
                  <h2 class="ec-title">Special Offer</h2>
                </div>
              </div>
              <div class="ec-new-slider">
                <?php
                $ret=mysqli_query($con,"select * from tblproducts where Status='Special' order by rand()");
                while ($row=mysqli_fetch_array($ret)) 
                {
                  $discount=$row['ProductDiscount'];
                  ?>
                  <div class="col-sm-12 ec-all-product-block">
                    <div class="ec-all-product-inner">
                      <div class="ec-pro-image-outer">
                        <div class="ec-pro-image">
                          <a href="product.php?pid=<?php echo htmlentities($row['id']);?>" class="image">
                            <img class="main-image" src="admin/productimages/<?php echo htmlentities($row['ProductImage']);?>"
                            alt="Product" />
                          </a>
                        </div>
                      </div>
                      <div class="ec-pro-content">
                        <h5 class="ec-pro-title"><a href="product.php?pid=<?php echo htmlentities($row['id']);?>"><?php echo htmlentities($row['ProductName']);?></a></h5>
                        <h6 class="ec-pro-stitle">
                          <?php
                          $category=$row['CategoryName'];
                          $ret2=mysqli_query($con,"select * from tblcategory where id=$category ");
                          while ($row2=mysqli_fetch_array($ret2))
                          {
                            ?>
                            <a href="shop-left-sidebar-col-3.html"><?php echo htmlentities($row2['CategoryName']);?></a>
                            <?php
                          }
                          ?>

                        </h6>
                        <div class="ec-pro-rat-price">
                          <div class="ec-pro-rat-pri-inner">
                            <span class="ec-price">
                              <span class="new-price">$&nbsp;<?php echo htmlentities(number_format($row['ProductPrice'], 0, '.', ','));?></span>
                              <span class="old-price">$&nbsp;<?php echo htmlentities(number_format($row['ProductPrice'], 0, '.', ','));?></span>
                              <span class="qty">- <?php echo htmlentities($row['Quantity']);?></span>
                            </span>
                          </div>
                        </div>
                      </div>
                      <span class="label veg" title="Veg">
                        <span class="dot"></span>
                      </span>
                    </div>
                  </div>
                  <?php
                }
                ?>
              </div>
            </div>
          </div>
        </div>
      </section>
      <!-- End Testimonial & new product section -->

      <!-- Ec Instagram Start -->
      <section class="section ec-instagram-section section-space-pt">
        <h2 class="d-none">Instagram</h2>
        <div class="ec-insta-wrapper" data-animation="fadeIn">
          <div class="ec-insta-outer">
            <div class="insta-auto">
              
              <?php
              $ret3=mysqli_query($con,"select * from tblproducts where Status='New' order by rand()");
              while ($row3=mysqli_fetch_array($ret3)) 
              {
                ?>
                <div class="ec-insta-item">
                  <div class="ec-insta-inner">
                    <a href="#" target="_blank"><img src="admin/productimages/<?php echo htmlentities($row3['ProductImage']);?>" alt="">

                    </a>
                  </div>
                </div>
                <?php
              } ?>
            </div>
          </div>
        </div>
      </section>
      <!-- Ec Instagram End -->

      <!-- Footer Start -->
      <?php @include("includes/footer.php");?>
      <!-- Footer Area End -->

      <!-- Click To Call -->
      <div class="ec-cc-style cc-right-bottom">
        <!-- Start Floating Panel Container -->
        <div class="cc-panel">			
          <!-- Panel Content -->
          <div class="cc-header">
            <img src="assets/images/whatsapp/profile_04.jpg" alt="profile image"/>
            <h2>Deekshitha Kotte</h2>
            <p>Technical Support</p>
          </div>
          <div class="cc-body">
            <p><b>Hey there &#128515;</b></p>
            <p>Need help ? just give me a call.</p>
          </div>
          <div class="cc-footer">
            <a href="tel:+919095649052" class="cc-call-button">
              <span>Call me</span>
              <svg width="13px" height="10px" viewBox="0 0 13 10">
                <path d="M1,5 L11,5"></path>
                <polyline points="8 1 12 5 8 9"></polyline>
              </svg>
            </a>
          </div>
        </div>
        <!--/ End Floating Panel Container -->

        <!-- Start Right Floating Button-->
        <div class="cc-button cc-right-bottom">
          <img src="assets/images/icons/call.svg" class="svg_img cc-call-svg" alt="call image" />
        </div>
        <!--/ End Right Floating Button-->

      </div>
      <!-- Click To Call end -->

      <!-- Newsletter Modal Start -->
      <div id="ec-popnews-bg"></div>
      <div id="ec-popnews-box">
        <div id="ec-popnews-close"><i class="ecicon eci-close"></i></div>
        <div class="row">
          <div class="col-md-6 disp-no-767">
            <img src="assets/images/banner/newsletter-8.jpg" alt="newsletter">
          </div>
          <div class="col-md-6">
            <div id="ec-popnews-box-content">
              <h2>Stay home, stay safe & get your daily needs from grocery shop.</h2>
              <p>Subscribe the grocery website to get in touch and get the future update. </p>
              <div id="form_status"></div>
              <form  method="post" id="subscribe-form" onSubmit="return valid_datas( this );" enctype="multipart/form-data">
                <input type="email" name="email" id="email" placeholder="Email Address"/>
                <button type="submit" class="btn btn-primary" name="subscribe">Subscribe</button>
              </form>
            </div>
          </div>
        </div>
      </div>
      
      <div class="ec-nav-toolbar">
        <div class="container">
          <div class="ec-nav-panel">
            <div class="ec-nav-panel-icons">
              <a href="#ec-mobile-menu" class="navbar-toggler-btn ec-header-btn ec-side-toggle">
                <img src="assets/images/icons/menu.svg" class="svg_img header_svg" alt="" />
              </a>
            </div>
            <div class="ec-nav-panel-icons">
              <a href="#ec-side-cart" class="toggle-cart ec-header-btn ec-side-toggle">  <img src="assets/images/icons/cart.svg" class="svg_img header_svg" alt="" />
                <?php
                if(!empty($_SESSION['cart']))
                {
                $sql = "SELECT * FROM tblproducts WHERE id IN(";
                foreach($_SESSION['cart'] as $id => $value){
                  $sql .=$id. ",";
                }
                $sql=substr($sql,0,-1) . ") ORDER BY id ASC";
                $query = mysqli_query($con,$sql);
                $totalprice=0;
                $totalqunty=0;
                if(!empty($query)){
                  while($row = mysqli_fetch_array($query))
                  {
                    $quantity=$_SESSION['cart'][$row['id']]['quantity'];
                    $subtotal= $_SESSION['cart'][$row['id']]['quantity']*$row['ProductPrice'];
                    $totalprice += $subtotal;
                    $_SESSION['qnty']=$totalqunty+=$quantity;
                  }
                }
                  ?>
                  <span class="ec-cart-noti ec-header-count cart-count-lable"><?php echo $_SESSION['qnty'];?></span>
                  <?php
                }else{?>
                  <span class="ec-cart-noti ec-header-count cart-count-lable">0</span>
                  <?php
                }
                ?>
              </a>
            </div>
            <div class="ec-nav-panel-icons">
              <a href="index.php" class="ec-header-btn">
                <img src="assets/images/icons/home.svg"
                class="svg_img header_svg" alt="icon" />
              </a>
            </div>
            <div class="ec-nav-panel-icons">
              <a href="wishlist.php" class="ec-header-btn">
                <img src="assets/images/icons/wishlist.svg" class="svg_img header_svg" alt="icon" />
                <?php
                if(strlen($_SESSION['login'])==0)
                {   
                  ?>
                  <span class="ec-cart-noti">0</span></a>
                  <?php
                }
                else{
                  $ret=mysqli_query($con,"select count(userId) as total  from wishlist where userId='".$_SESSION['id']."'");
                  $num=mysqli_fetch_array($ret);
                  $count=$num['total'];
                  ?>
                  <span class="ec-cart-noti"><?php echo $count?></span>

                  <?php
                }?>
              </a>
            </div>
            <div class="ec-nav-panel-icons">
              <a href="login.php" class="ec-header-btn">
                <img src="assets/images/icons/user.svg"
                class="svg_img header_svg" alt="icon" />
              </a>
            </div>

          </div>
        </div>
      </div>
      <!-- Footer navigation panel for responsive display end -->

      <!-- Add to Cart successfully toast Start -->
      <div id="addtocart_toast" class="addtocart_toast">
        <div class="desc">You Have Add To Cart Successfully</div>
      </div>
      <!-- Add to Cart successfully toast end -->

      <!-- Vendor JS -->
      <script data-cfasync="false" src="/cdn-cgi/scripts/5c5dd728/cloudflare-static/email-decode.min.js"></script><script src="assets/js/vendor/jquery-3.5.1.min.js"></script>
      <script src="assets/js/vendor/jquery.notify.min.js"></script>
      <script src="assets/js/vendor/jquery.bundle.notify.min.js"></script>
      <script src="assets/js/vendor/popper.min.js"></script>
      <script src="assets/js/vendor/bootstrap.min.js"></script>
      <script src="assets/js/vendor/jquery-migrate-3.3.0.min.js"></script>
      <script src="assets/js/vendor/modernizr-3.11.2.min.js"></script>

      <!--Plugins JS-->
      <script src="assets/js/plugins/swiper-bundle.min.js"></script>
      <script src="assets/js/plugins/countdownTimer.min.js"></script>
      <script src="assets/js/plugins/scrollup.js"></script>
      <script src="assets/js/plugins/jquery.zoom.min.js"></script>
      <script src="assets/js/plugins/slick.min.js"></script>
      <script src="assets/js/plugins/infiniteslidev2.js"></script>
      <script src="assets/js/plugins/click-to-call.js"></script>

      <!-- Main Js -->
      <script src="assets/js/vendor/index.js"></script>
      <script src="assets/js/demo-6.js"></script>
      <script src="assets/js/form-validate2.js"></script>

    </body>

    </html>