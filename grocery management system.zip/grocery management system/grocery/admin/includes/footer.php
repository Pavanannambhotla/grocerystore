<footer class="footer mt-auto">
	<div class="copyright bg-white">
		<p>
			Copyright &copy; <span id="ec-year"></span><a class="text-primary"
			href="http://localhost/grocery%20management%20system/grocery/index.php#" target="_blank"> Grocery Shop Admin Dashboard</a>. All Rights Reserved.
		</p>
	</div>
</footer>