<?php
session_start();
error_reporting(0);
include('includes/dbconnection.php');
// Code for User login
if(isset($_POST['login']))
{
  $email=$_POST['email'];
  $password=md5($_POST['password']);
  $query=mysqli_query($con,"SELECT * FROM users WHERE email='$email' and password='$password'");
  $num=mysqli_fetch_array($query);
  if($num>0)
  {

    $_SESSION['login']=$num['email'];
    $_SESSION['id']=$num['id'];
    $_SESSION['contact']=$num['contactno'];
    $_SESSION['username']=$num['name'];

    echo "<script type='text/javascript'> document.location ='user-profile.php'; </script>";
  }
  else
  {
    echo "<script>alert('failed wrong credentials!');</script>";
  }
}


?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta http-equiv="x-ua-compatible" content="ie=edge" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=1.0">

  <title>Online Grocery Shop</title>
  <meta name="keywords" content="apparel, catalog, clean, ecommerce, ecommerce HTML, electronics, grocery, html eCommerce, html store, minimal, multipurpose, multipurpose ecommerce, online store, responsive ecommerce template, shops" />
  <meta name="description" content="Best ecommerce html template for single and multi vendor store.">
  <meta name="author" content="Code4berry">

  <!-- site Favicon -->
  <link rel="icon" href="assets/images/favicon/favicon.png" sizes="32x32" />
  <link rel="apple-touch-icon" href="assets/images/favicon/favicon-10.png" />
  <meta name="msapplication-TileImage" content="assets/images/favicon/favicon-10.png" />

  <!-- css Icon Font -->
  <link rel="stylesheet" href="assets/css/vendor/ecicons.min.css" />

  <!-- css All Plugins Files -->
  <link rel="stylesheet" href="assets/css/plugins/animate.css" />
  <link rel="stylesheet" href="assets/css/plugins/swiper-bundle.min.css" />
  <link rel="stylesheet" href="assets/css/plugins/jquery-ui.min.css" />
  <link rel="stylesheet" href="assets/css/plugins/countdownTimer.css" />
  <link rel="stylesheet" href="assets/css/plugins/slick.min.css" />
  <link rel="stylesheet" href="assets/css/plugins/bootstrap.css" />

  <!-- Main Style -->
  <link rel="stylesheet" href="assets2/css/style.css" />
  <link rel="stylesheet" href="assets2/css/responsive.css" />
  <!-- <script src='https://www.google.com/recaptcha/api.js'></script> --> 

</head>
<body>
  <div id="ec-overlay"><span class="loader_img"></span></div>
  <!-- Header start  -->
  <?php @include("includes/second_header.php");?>
  <!-- Header End  -->

  <!-- Ekka Cart Start -->
  <?php @include("includes/shoppingcart.php");?>
  <!-- Ekka Cart End -->


  <!-- Ec breadcrumb start -->
  <div class="sticky-header-next-sec  ec-breadcrumb section-space-mb">
    <div class="container">
      <div class="row">
        <div class="col-12">
          <div class="row ec_breadcrumb_inner">
            <div class="col-md-6 col-sm-12">
              <h2 class="ec-breadcrumb-title">Login</h2>
            </div>
            <div class="col-md-6 col-sm-12">
              <!-- ec-breadcrumb-list start -->
              <ul class="ec-breadcrumb-list">
                <li class="ec-breadcrumb-item"><a href="index.php">Home</a></li>
                <li class="ec-breadcrumb-item active">Login</li>
              </ul>
              <!-- ec-breadcrumb-list end -->
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
  <!-- Ec breadcrumb end -->

  <!-- Ec login page -->
  <section class="ec-page-content section-space-p">
    <div class="container">
      <div class="row">
        <div class="col-md-12 text-center">
          <div class="section-title">
            <h2 class="ec-bg-title">Log In</h2>
            <h2 class="ec-title">Log In</h2>
            <p class="sub-title mb-3">Best place to buy and sell digital products</p>
          </div>
        </div>
        <div class="ec-login-wrapper">
          <div class="ec-login-container">
            <div class="ec-login-form">
              <form action="#" method="post">
                <span class="ec-login-wrap">
                  <label>Email Address*</label>
                  <input type="text" name="email" placeholder="Enter your email add..." required />
                </span>
                <span class="ec-login-wrap">
                  <label>Password*</label>
                  <input type="password" name="password" placeholder="Enter your password" required />
                </span>
                <span class="ec-login-wrap ec-login-fp">
                  <label><a href="forgot_password.php">Forgot Password?</a></label>
                </span>
                <span class="ec-login-wrap ec-login-btn">
                  <button class="btn btn-primary" name="login" type="submit">Login</button>
                </span>
              </form>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>
  <!-- Footer Start -->
  <?php @include("includes/footer.php");?>
  <!-- Footer Area End -->
  <!-- Footer navigation panel for responsive display -->
  <div class="ec-nav-toolbar">
    <div class="container">
      <div class="ec-nav-panel">
        <div class="ec-nav-panel-icons">
          <a href="#ec-mobile-menu" class="navbar-toggler-btn ec-header-btn ec-side-toggle">
            <img src="assets/images/icons/menu.svg" class="svg_img header_svg" alt="" />
          </a>
        </div>
        <div class="ec-nav-panel-icons">
          <a href="#ec-side-cart" class="toggle-cart ec-header-btn ec-side-toggle">  <img src="assets/images/icons/cart.svg" class="svg_img header_svg" alt="" />
            <?php
            if(!empty($_SESSION['cart']))
            {
              $sql = "SELECT * FROM tblproducts WHERE id IN(";
              foreach($_SESSION['cart'] as $id => $value){
                $sql .=$id. ",";
              }
              $sql=substr($sql,0,-1) . ") ORDER BY id ASC";
              $query = mysqli_query($con,$sql);
              $totalprice=0;
              $totalqunty=0;
              if(!empty($query)){
                while($row = mysqli_fetch_array($query))
                {
                  $quantity=$_SESSION['cart'][$row['id']]['quantity'];
                  $subtotal= $_SESSION['cart'][$row['id']]['quantity']*$row['ProductPrice'];
                  $totalprice += $subtotal;
                  $_SESSION['qnty']=$totalqunty+=$quantity;
                }
              }
              

              ?>
              <span class="ec-cart-noti ec-header-count cart-count-lable"><?php echo $_SESSION['qnty'];?></span>
              <?php
            }else{?>
              <span class="ec-cart-noti ec-header-count cart-count-lable">0</span>
              <?php
            }
            ?>
          </a>
        </div>
        <div class="ec-nav-panel-icons">
          <a href="index.php" class="ec-header-btn">
            <img src="assets/images/icons/home.svg"
            class="svg_img header_svg" alt="icon" />
          </a>
        </div>
        <div class="ec-nav-panel-icons">
          <a href="wishlist.php" class="ec-header-btn">
            <img src="assets/images/icons/wishlist.svg" class="svg_img header_svg" alt="icon" />
            <?php
            if(strlen($_SESSION['login'])==0)
            {   
              ?>
              <span class="ec-cart-noti">0</span></a>
              <?php
            }
            else{
              $ret=mysqli_query($con,"select count(userId) as total  from wishlist where userId='".$_SESSION['id']."'");
              $num=mysqli_fetch_array($ret);
              $count=$num['total'];
              ?>
              <span class="ec-cart-noti"><?php echo $count?></span>
              
              <?php
            }?>
          </a>
        </div>
        <div class="ec-nav-panel-icons">
          <a href="login.php" class="ec-header-btn">
            <img src="assets/images/icons/user.svg"
            class="svg_img header_svg" alt="icon" />
          </a>
        </div>

      </div>
    </div>
  </div>
  <!-- Footer navigation panel for responsive display end -->
  <!-- Vendor JS -->
  <script src="assets/js/vendor/jquery-3.5.1.min.js"></script>
  <script src="assets/js/vendor/jquery.notify.min.js"></script>
  <script src="assets/js/vendor/jquery.bundle.notify.min.js"></script>
  <script src="assets/js/vendor/popper.min.js"></script>
  <script src="assets/js/vendor/bootstrap.min.js"></script>
  <script src="assets/js/vendor/jquery-migrate-3.3.0.min.js"></script>
  <script src="assets/js/vendor/modernizr-3.11.2.min.js"></script>

  <!--Plugins JS-->
  <script src="assets/js/plugins/swiper-bundle.min.js"></script>
  <script src="assets/js/plugins/countdownTimer.min.js"></script>
  <script src="assets/js/plugins/scrollup.js"></script>
  <script src="assets/js/plugins/jquery.zoom.min.js"></script>
  <script src="assets/js/plugins/slick.min.js"></script>
  <script src="assets/js/plugins/infiniteslidev2.js"></script>
  <script src="assets/js/plugins/fb-chat.js"></script>
  <script src="assets/js/plugins/jquery.sticky-sidebar.js"></script>

  <!-- Main Js -->
  <script src="assets2/js/vendor/index.js"></script>
  <script src="assets2/js/main.js"></script>


</body>
</html>