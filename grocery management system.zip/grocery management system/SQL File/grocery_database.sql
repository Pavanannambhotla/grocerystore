-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 03, 2023 at 10:28 AM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `grocery_database`
--

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `id` int(11) NOT NULL,
  `userId` int(11) DEFAULT NULL,
  `productId` varchar(255) DEFAULT NULL,
  `InvoiceNumber` int(11) DEFAULT NULL,
  `quantity` int(11) DEFAULT NULL,
  `orderNote` varchar(255) DEFAULT NULL,
  `orderDate` timestamp NOT NULL DEFAULT current_timestamp(),
  `paymentMethod` varchar(50) DEFAULT NULL,
  `orderStatus` varchar(55) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`id`, `userId`, `productId`, `InvoiceNumber`, `quantity`, `orderNote`, `orderDate`, `paymentMethod`, `orderStatus`) VALUES
(67, 5, '86', 143314007, 1, 'make sure you deliver in 2hrs', '2022-11-07 13:52:36', 'Cash On Delivery', NULL),
(68, 5, '92', 143314007, 1, 'make sure you deliver in 2hrs', '2022-11-07 13:52:36', 'Cash On Delivery', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `permissions`
--

CREATE TABLE `permissions` (
  `id` int(11) NOT NULL,
  `permission` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `createuser` varchar(255) DEFAULT NULL,
  `deleteuser` varchar(255) DEFAULT NULL,
  `createbid` varchar(255) DEFAULT NULL,
  `updatebid` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `permissions`
--

INSERT INTO `permissions` (`id`, `permission`, `createuser`, `deleteuser`, `createbid`, `updatebid`) VALUES
(1, 'Superuser', '1', '1', '1', '1'),
(2, 'Admin', '1', NULL, '1', '1'),
(3, 'User', NULL, NULL, '1', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `productreviews`
--

CREATE TABLE `productreviews` (
  `id` int(11) NOT NULL,
  `productId` int(11) DEFAULT NULL,
  `rating` int(11) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `review` longtext DEFAULT NULL,
  `reviewDate` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `productreviews`
--

INSERT INTO `productreviews` (`id`, `productId`, `rating`, `name`, `email`, `review`, `reviewDate`) VALUES
(8, 66, 5, 'Arinaitwe Gerald', 'gerald@gmail.com', 'your product is good', '2022-02-23 11:35:12'),
(12, 98, 4, 'John Simith', 'john@gmail.com', 'This is the quality product that I was been looking for many years', '2022-02-23 12:11:38'),
(13, 38, 3, 'Amanya Owen', 'owen@gmail.com', 'i like that laptop', '2022-03-01 09:11:28'),
(14, 41, 2, 'Arinaitwe Gerald', 'gerald@gmail.com', 'I like your product', '2022-03-07 08:19:40'),
(19, 95, 1, 'Arinaitwe owen', 'owen@gmail.com', 'This is product I was been looking', '2022-03-07 09:47:58');

-- --------------------------------------------------------

--
-- Table structure for table `tbladmin`
--

CREATE TABLE `tbladmin` (
  `ID` int(10) NOT NULL,
  `Staffid` int(10) DEFAULT NULL,
  `AdminName` varchar(120) DEFAULT NULL,
  `UserName` varchar(120) DEFAULT NULL,
  `FirstName` varchar(255) DEFAULT NULL,
  `LastName` varchar(255) DEFAULT NULL,
  `MobileNumber` bigint(10) DEFAULT NULL,
  `Email` varchar(200) DEFAULT NULL,
  `Birthday` varchar(255) DEFAULT NULL,
  `Status` int(11) NOT NULL DEFAULT 1,
  `activationcode` varchar(255) NOT NULL DEFAULT 'g2o9@h3$n%&h09',
  `Photo` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL DEFAULT 'avatar15.jpg',
  `Password` varchar(120) DEFAULT NULL,
  `AdminRegdate` timestamp NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tbladmin`
--

INSERT INTO `tbladmin` (`ID`, `Staffid`, `AdminName`, `UserName`, `FirstName`, `LastName`, `MobileNumber`, `Email`, `Birthday`, `Status`, `activationcode`, `Photo`, `Password`, `AdminRegdate`) VALUES
(2, 1002, 'Admin', 'admin', 'John', 'Simith', 770546590, 'geraldarinaitwe123@gmail.com', NULL, 1, '97310958f46eb70791559fd32628bfc1', 'face19.jpg', '81dc9bdb52d04dc20036dbd8313ed055', '2021-06-21 10:18:39'),
(29, 1008, 'User', 'gloria', 'Patience', 'Gloria', 770546590, 'gloria@gmail.com', NULL, 1, 'g2o9@h3$n%&h09', 'avatar15.jpg', '81dc9bdb52d04dc20036dbd8313ed055', '2021-08-25 11:29:20'),
(30, NULL, NULL, 'gerald', 'Arinaitwe', 'Gerald', NULL, 'gerald@gmail.com', NULL, 0, 'g2o9@h3$n%&h09', 'avatar15.jpg', NULL, '2022-08-23 11:24:18'),
(32, NULL, NULL, 'gerald', 'Amanya', 'Owen', NULL, 'owen@gmail.com', NULL, 1, 'g2o9@h3$n%&h09', 'avatar15.jpg', NULL, '2022-08-23 11:33:08');

-- --------------------------------------------------------

--
-- Table structure for table `tblbrand`
--

CREATE TABLE `tblbrand` (
  `id` int(10) NOT NULL,
  `BrandName` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci DEFAULT NULL,
  `BrandImage` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci DEFAULT NULL,
  `PostingDate` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tblbrand`
--

INSERT INTO `tblbrand` (`id`, `BrandName`, `BrandImage`, `PostingDate`) VALUES
(1, 'Samsung', 'samsung.png', '2022-02-24 11:26:07'),
(2, 'Lenovo', 'lenovo.png', '2022-02-24 11:26:21'),
(3, 'Hp', 'hp.png', '2022-02-24 11:26:34'),
(4, 'Dell', 'dell.png', '2022-02-24 11:26:52'),
(5, 'Sony', 'sony.png', '2022-02-24 11:27:19'),
(6, 'Tecno', 'tecno.png', '2022-02-24 11:29:06'),
(7, 'Nokia', 'nokia.png', '2022-03-22 11:49:57'),
(13, 'iphone', 'apple.png', '2022-09-21 07:32:15'),
(22, 'Hisense', 'hisense.png', '2022-10-09 08:38:44');

-- --------------------------------------------------------

--
-- Table structure for table `tblcategory`
--

CREATE TABLE `tblcategory` (
  `id` int(11) NOT NULL,
  `CategoryName` varchar(200) DEFAULT NULL,
  `Categorydescription` varchar(50) DEFAULT NULL,
  `Tags` longtext DEFAULT NULL,
  `PostingDate` timestamp NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `tblcategory`
--

INSERT INTO `tblcategory` (`id`, `CategoryName`, `Categorydescription`, `Tags`, `PostingDate`) VALUES
(78, 'Vegetables', 'Lorem Ipsum is simply dummy text of the printing a', '', '2022-10-25 06:01:47'),
(79, 'Fresh Fruits', 'Lorem Ipsum is simply dummy text of the printing a', '', '2022-10-25 06:02:14');

-- --------------------------------------------------------

--
-- Table structure for table `tblcompany`
--

CREATE TABLE `tblcompany` (
  `id` int(11) NOT NULL,
  `regno` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci DEFAULT NULL,
  `companyname` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci DEFAULT NULL,
  `companyemail` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci DEFAULT NULL,
  `country` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci DEFAULT NULL,
  `companyphone` int(10) NOT NULL,
  `companyaddress` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `companylogo` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL DEFAULT 'avatar15.jpg',
  `status` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL DEFAULT '0',
  `creationdate` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tblcompany`
--

INSERT INTO `tblcompany` (`id`, `regno`, `companyname`, `companyemail`, `country`, `companyphone`, `companyaddress`, `companylogo`, `status`, `creationdate`) VALUES
(4, '0008778', 'CODE4BERRY  LTD', 'code4berry@gmail.com', 'Canada', 770578453, 'Parliamentary Avenue, Eco bank plaza', 'logo2.png', '1', '2021-02-02 12:17:15');

-- --------------------------------------------------------

--
-- Table structure for table `tblproducts`
--

CREATE TABLE `tblproducts` (
  `id` int(11) NOT NULL,
  `CategoryName` int(11) DEFAULT NULL,
  `ProductName` varchar(150) DEFAULT NULL,
  `Slug` varchar(255) DEFAULT NULL,
  `Grouptag` varchar(255) DEFAULT NULL,
  `Quantity` varchar(255) DEFAULT NULL,
  `Status` varchar(255) DEFAULT NULL,
  `ProductImage` varchar(255) DEFAULT NULL,
  `ProductImage2` varchar(255) DEFAULT NULL,
  `ProductImage3` varchar(255) DEFAULT NULL,
  `ProductImage4` varchar(255) DEFAULT NULL,
  `ProductPrice` decimal(10,0) DEFAULT NULL,
  `PriceBefore` decimal(10,0) NOT NULL,
  `productDescription` longtext DEFAULT NULL,
  `ProductStatus` varchar(255) DEFAULT NULL,
  `PostingDate` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `UpdationDate` timestamp NULL DEFAULT NULL ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `tblproducts`
--

INSERT INTO `tblproducts` (`id`, `CategoryName`, `ProductName`, `Slug`, `Grouptag`, `Quantity`, `Status`, `ProductImage`, `ProductImage2`, `ProductImage3`, `ProductImage4`, `ProductPrice`, `PriceBefore`, `productDescription`, `ProductStatus`, `PostingDate`, `UpdationDate`) VALUES
(85, 79, 'mango', NULL, '', '1 kg', 'New', 'mango2.jpg', 'mango.jpg', 'mango2.jpg', 'mango.jpg', 7, 10, 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s', NULL, '2022-10-25 06:18:07', NULL),
(86, 79, 'Pineapple', NULL, '', '-2', 'New', 'pineapple.jpg', 'pineapple2.jpg', 'pineapple.jpg', 'pineapple2.jpg', 4, 6, 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s', NULL, '2022-11-08 07:53:30', '2022-11-08 07:53:30'),
(87, 79, 'blackberry', NULL, '', '1 Pcs', 'New', 'black_berry.jpg', 'black_berry2.jpg', 'black_berry.jpg', 'black_berry2.jpg', 5, 8, 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s', NULL, '2022-10-25 06:21:13', NULL),
(88, 78, 'carrots', NULL, '', '-1', 'New', 'carrots.jpg', 'carrots2.jpg', 'carrots.jpg', 'carrots2.jpg', 8, 12, 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s', NULL, '2023-03-30 07:02:42', '2023-03-30 07:02:42'),
(89, 78, 'tomatoes', NULL, '', '-1', 'New', 'tomato.jpg', 'tomato2.jpg', 'tomato.jpg', 'tomato2.jpg', 4, 6, 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s', NULL, '2022-11-08 08:16:45', '2022-11-08 08:16:45'),
(90, 78, 'onion', NULL, '', 'I Kg', 'New', 'onion.jpg', 'onion2.jpg', 'onion.jpg', 'onion2.jpg', 6, 8, 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s', NULL, '2022-10-25 06:26:52', NULL),
(91, 79, 'Raspberry', NULL, '', '1 Pcs', 'New', 'raspberry.jpg', 'raspberry2.jpg', 'raspberry.jpg', 'raspberry2.jpg', 5, 7, 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s', NULL, '2022-10-25 06:29:10', NULL),
(92, 79, 'Yellow banana', NULL, '', '0', 'New', 'yellow_banana2.jpg', 'yellow_banana.jpg', 'yellow_banana2.jpg', 'yellow_banana.jpg', 3, 5, 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s', NULL, '2022-11-06 13:52:36', '2022-11-06 13:52:36'),
(93, 78, 'Green pepper', NULL, '', '1 Kg', 'New', 'green pepper.jpg', 'green pepper2.jpg', 'green pepper.jpg', 'green pepper2.jpg', 10, 12, 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s', NULL, '2022-10-25 06:31:44', NULL),
(94, 79, 'orange', '', '', '-2', 'New', 'orange2.jpg', 'orange.jpg', 'orange2.jpg', 'orange.jpg', 14, 16, 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s', NULL, '2022-11-08 07:53:30', '2022-11-08 07:53:30'),
(95, 79, 'Lemon', NULL, '', '1 Kg', 'New', 'lemon2.jpg', 'lemon.jpg', 'lemon2.jpg', 'lemon.jpg', 8, 12, 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s', NULL, '2022-10-25 07:20:45', NULL),
(96, 79, 'Purple passion fruit', NULL, '', '1 Kg', 'Special', 'purple passion fruit.jpg', 'purple passion fruit2.jpg', 'purple passion fruit.jpg', 'purple passion fruit2.jpg', 45, 50, 'Lorem ipsum dolor sit amet consectetur Lorem ipsum dolor dolor sit amet consectetur Lorem ipsum dolor', NULL, '2022-11-04 13:58:10', NULL),
(98, 79, 'Yellow mango', NULL, '', '-2', 'Special', 'yellow mango2.jpg', 'yellow mango.jpg', 'yellow mango2.jpg', 'yellow mango.jpg', 56, 70, 'Lorem ipsum dolor sit amet consectetur Lorem ipsum dolor dolor sit amet consectetur Lorem ipsum dolor', NULL, '2022-11-08 08:16:45', '2022-11-08 08:16:45'),
(101, 79, 'Apple', NULL, '', '1 Kg', 'Special', 'apple.jpg', 'apple2.jpg', 'apple.jpg', 'apple2.jpg', 80, 99, 'Lorem ipsum dolor sit amet consectetur Lorem ipsum dolor dolor sit amet consectetur Lorem ipsum dolor', NULL, '2022-11-04 13:58:59', NULL),
(102, 79, 'Jack Fruit', NULL, '', '1PCS', 'Special', 'jack_fruit2.jpg', 'jack_fruit.jpg', 'jack_fruit2.jpg', 'jack_fruit.jpg', 30, 40, 'Lorem ipsum dolor sit amet consectetur Lorem ipsum dolor dolor sit amet consectetur Lorem ipsum dolor', NULL, '2022-11-04 13:46:15', NULL),
(104, 79, 'Maize', NULL, '', '1 Kg', 'Special', 'maize.jpg', 'maize2.jpg', 'maize.jpg', '', 45, 65, 'Lorem ipsum dolor sit amet consectetur Lorem ipsum dolor dolor sit amet consectetur Lorem ipsum dolor', NULL, '2022-11-04 13:48:21', NULL),
(105, 79, 'Ovacado', NULL, '', '1 Kg', 'Special', 'ovacado2.jpg', 'ovacado.jpg', 'ovacado2.jpg', 'ovacado.jpg', 65, 66, 'Lorem ipsum dolor sit amet consectetur Lorem ipsum dolor dolor sit amet consectetur Lorem ipsum dolor', NULL, '2022-11-04 13:49:09', NULL),
(106, 79, 'PumpKin', NULL, '', '1 Kg', 'Special', 'pumpkin.jpg', 'pumpkin2.jpg', 'pumpkin.jpg', 'pumpkin2.jpg', 87, 99, 'Lorem ipsum dolor sit amet consectetur Lorem ipsum dolor dolor sit amet consectetur Lorem ipsum dolor', NULL, '2022-11-04 13:52:05', NULL),
(107, 79, 'Water Mellon', NULL, '', '1 Pcs', 'Special', 'water mellon.jpg', 'water mellon2.jpg', 'water mellon.jpg', 'water mellon2.jpg', 55, 77, 'Lorem ipsum dolor sit amet consectetur Lorem ipsum dolor dolor sit amet consectetur Lorem ipsum dolor', NULL, '2022-11-04 13:53:25', NULL),
(108, 79, 'Guava', NULL, '', '1 Kg', 'Special', 'guava.jpg', 'guava2.jpg', 'guava.jpg', 'guava2.jpg', 44, 55, 'Lorem ipsum dolor sit amet consectetur Lorem ipsum dolor dolor sit amet consectetur Lorem ipsum dolor', NULL, '2022-11-04 13:56:50', NULL),
(109, 79, 'Yellow passion fruit', '', '', '1 Kg', 'Special', 'yellow passion fruit.jpg', 'yellow passion fruit2.jpg', 'yellow passion fruit.jpg', 'yellow passion fruit2.jpg', 66, 88, 'Lorem ipsum dolor sit amet consectetur Lorem ipsum dolor dolor sit amet consectetur Lorem ipsum dolor', NULL, '2022-11-08 08:53:38', '2022-11-08 08:53:38');

-- --------------------------------------------------------

--
-- Table structure for table `tblsubscribe`
--

CREATE TABLE `tblsubscribe` (
  `id` int(10) NOT NULL,
  `email` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci DEFAULT NULL,
  `subscribed_date` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tblsubscribe`
--

INSERT INTO `tblsubscribe` (`id`, `email`, `subscribed_date`) VALUES
(2, 'gerald@gmail.com', '2022-03-01 12:46:06'),
(15, 'linda@gmail.com', '2022-09-23 09:57:58'),
(16, 'owen@gmail.com', '2022-09-23 10:00:01'),
(17, 'john@gmail.com', '2022-09-23 10:00:32'),
(18, 'dokampu@yahoo.com', '2022-09-23 10:01:50'),
(19, 'geraldarinaitwe123@gmail.com', '2022-09-23 10:02:12'),
(20, 'kevin@gmail.com', '2022-09-23 10:03:13'),
(21, '', '2022-11-04 14:55:52'),
(22, 'dompu@yahoo.com', '2022-11-05 19:49:32'),
(23, 'owen44@gmail.com', '2022-11-05 20:01:28'),
(24, 'owen8@gmail.com', '2022-11-05 20:05:26'),
(25, 'john55@gmail.com', '2022-11-08 08:20:08');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `contactno` bigint(11) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `shippingAddress` longtext DEFAULT NULL,
  `shippingCountry` varchar(255) DEFAULT NULL,
  `shippingCity` varchar(255) DEFAULT NULL,
  `shippingZipcode` int(11) DEFAULT NULL,
  `shippingContact` int(10) DEFAULT NULL,
  `billingAddress` varchar(255) DEFAULT NULL,
  `billingCountry` varchar(255) DEFAULT NULL,
  `billingCity` varchar(255) DEFAULT NULL,
  `billingState` varchar(255) DEFAULT NULL,
  `billingZipcode` int(11) DEFAULT NULL,
  `billingContact` int(11) DEFAULT NULL,
  `activationcode` varchar(255) NOT NULL DEFAULT 'g2o9@h3$n%&h09',
  `regDate` timestamp NOT NULL DEFAULT current_timestamp(),
  `updationDate` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `contactno`, `password`, `shippingAddress`, `shippingCountry`, `shippingCity`, `shippingZipcode`, `shippingContact`, `billingAddress`, `billingCountry`, `billingCity`, `billingState`, `billingZipcode`, `billingContact`, `activationcode`, `regDate`, `updationDate`) VALUES
(5, 'John Simith', 'gerald@gmail.com', 770546590, '81dc9bdb52d04dc20036dbd8313ed055', 'Parkrise Road', 'Canada', 'California', 256, NULL, 'Parkrise Road', 'Canada', 'California', NULL, 256, 770546590, '5b695445d89838bb38845b27c33c8f39', '2022-02-18 09:00:57', '');

-- --------------------------------------------------------

--
-- Table structure for table `wishlist`
--

CREATE TABLE `wishlist` (
  `id` int(11) NOT NULL,
  `userId` int(11) DEFAULT NULL,
  `productId` int(11) DEFAULT NULL,
  `postingDate` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `wishlist`
--

INSERT INTO `wishlist` (`id`, `userId`, `productId`, `postingDate`) VALUES
(27, 30, 75, '2022-10-03 11:16:36'),
(33, 5, 88, '2022-10-26 09:44:25');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `permissions`
--
ALTER TABLE `permissions`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `productreviews`
--
ALTER TABLE `productreviews`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbladmin`
--
ALTER TABLE `tbladmin`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `tblbrand`
--
ALTER TABLE `tblbrand`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tblcategory`
--
ALTER TABLE `tblcategory`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tblcompany`
--
ALTER TABLE `tblcompany`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tblproducts`
--
ALTER TABLE `tblproducts`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tblsubscribe`
--
ALTER TABLE `tblsubscribe`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `wishlist`
--
ALTER TABLE `wishlist`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `orders`
--
ALTER TABLE `orders`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=74;

--
-- AUTO_INCREMENT for table `permissions`
--
ALTER TABLE `permissions`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `productreviews`
--
ALTER TABLE `productreviews`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- AUTO_INCREMENT for table `tbladmin`
--
ALTER TABLE `tbladmin`
  MODIFY `ID` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=36;

--
-- AUTO_INCREMENT for table `tblbrand`
--
ALTER TABLE `tblbrand`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;

--
-- AUTO_INCREMENT for table `tblcategory`
--
ALTER TABLE `tblcategory`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=80;

--
-- AUTO_INCREMENT for table `tblcompany`
--
ALTER TABLE `tblcompany`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `tblproducts`
--
ALTER TABLE `tblproducts`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=110;

--
-- AUTO_INCREMENT for table `tblsubscribe`
--
ALTER TABLE `tblsubscribe`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=31;

--
-- AUTO_INCREMENT for table `wishlist`
--
ALTER TABLE `wishlist`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=35;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
